--[[ ============================================================================
 _   _  ___ _____ _     ___    _    ____  _____ ____
| | | |/ _ \_   _| |   / _ \  / \  |  _ \| ____|  _ \
| |_| | | | || | | |  | | | |/ _ \ | | | |  _| | |_) |
|  _  | |_| || | | |__| |_| / ___ \| |_| | |___|  _ <
|_| |_|\___/ |_| |_____\___/_/   \_\____/|_____|_| \_\

    HOTLOADER  v1.0.0
    ============================================================================
    Hotload ANY Steam Workshop addon into a running Garry's Mod server.
    No restart. No map reload. No server reboot. Right in the middle of the
    game, like absolute chads.

    FEATURES
      * Server-driven downloads through the gmsv_workshop module
        (steamworks.DownloadUGC on DEDICATED servers!)
      * Automatic sync: every player downloads & mounts the addon too,
        including players who join later
      * AUTO-HOTLOAD: subscribe to a Workshop addon in-game (Steam overlay)
        and it hotloads automatically, or tick an addon back ON in the
        Addons menu (it is already downloaded, so that one is instant).
        Both have their own checkbox in the Hotloader tab
      * MAP HOTLOADING: hotload a map addon and a LOAD MAP button appears -
        the server switches to it and every player can join (they all have
        the map mounted)
      * SOFT UNLOAD: the UNLOAD button strips an addon's hooks, timers and
        spawnmenu entries (files stay mounted - GMod cannot unmount, see
        README)
      * Requirement chains: an addon's "Required Items" get hotloaded too
      * Its own spawnmenu tabs in the TOP TAB ROW (next to Saves/Dupes):
        "Hotloader" and "Web Browser"
      * A built-in web browser: visit any Workshop addon page and a big
        green button is injected right next to Subscribe - it says HOTLOAD
        on normal addons and LOAD MAP on map addons (and actually switches
        the level!)
      * Runtime ammo types, toolgun STOOLs, scripted entities, weapons,
        effects, panels and gamemode hooks all initialize correctly mid-game
      * OPTIONAL: install GModPatchTool for a modern web engine so the
        built-in browser renders websites properly
        https://github.com/solsticegamestudios/GModPatchTool
		
      * Addon Is Open Sourced And Released Under M.I.T 
	  (You can use it for whatever you want, and or contribute if you wish, No Credit Is Needed)

    INSTALL
      1. Put this file in:  garrysmod/lua/autorun/hotloader.lua
      2. DEDICATED SERVERS ONLY: install the gmsv_workshop module
         (https://github.com/nooshstuff/gmsv_workshop, v3.0.4+):
           - Win64 : gmsv_workshop_win64.dll   -> garrysmod/lua/bin/
           - Linux64: gmsv_workshop_linux64.dll -> garrysmod/lua/bin/
         The file auto-detects the module on boot and tells you if it is
         missing. Listen servers / singleplayer work without it.

    USAGE
      * Spawnmenu (Q) -> "Hotloader" tab (top tab row)
      * Spawnmenu (Q) -> "Hotloader Browser" tab (top tab row, next to Saves)
      * Console: tbh_hotload <workshop id or url>
      * Console: tbh_loadmap <map>   (after hotloading a map addon)
      * Console: tbh_unload <id> [1] (soft unload; 1 = also remove entities)
      * Or simply subscribe to the addon in Steam / tick it on in Addons

    SERVER CONVARS
      tbh_permission    0 = everyone, 1 = admins (default), 2 = superadmins
      tbh_requirements  1 = also hotload an addon's Required Items
      tbh_max_files     20000 = max files per hotload
      tbh_timeout       180 = download watchdog (seconds)
      tbh_cooldown      10 = per-player request cooldown (seconds)
      tbh_max_queue     10 = max queued hotloads
      tbh_latesync      1 = sync addons to players who join later
      tbh_announce      1 = chat announcements
      tbh_cleanup_on_empty 1 = wipe the session when the last player leaves

    CLIENT CONVARS
      tbh_hints         1 = welcome hints
      tbh_logs          0 = verbose hotload logs in console
      tbh_autosubscribe 1 = subscribing to a NEW Workshop addon in-game
                        automatically requests a hotload
      tbh_enableaddons  1 = ticking an addon back ON in the Addons menu
                        hotloads it instantly (already downloaded)

    CREDITS
      Architecture inspired by "Midgame Workshop Hotloader" by Xalalau
      Xubilozo (workshop id 2885846408). This is a from-scratch rewrite:
      server-driven pipeline (dedicated-server ready via gmsv_workshop),
      chunked transfers, embedded browser, spawnmenu UI. No data ever
      leaves your server - there is no error reporting in this build.

    OPTIONAL (but recommended): GModPatchTool
      GMod's built-in web engine (CEF) is ancient and renders modern sites
      poorly - Steam pages may show missing images and empty lists in the
      built-in browser. GModPatchTool by Solstice Game Studios patches
      GMod with a modern CEF, which makes the Hotloader Browser look and
      work way better. It is 100% OPTIONAL - the hotloader works fine
      without it, it just makes the browser look better:
        https://github.com/solsticegamestudios/GModPatchTool
      (grab the latest release from the releases page)

    This file is fully standalone. One file. That's it. Enjoy.
============================================================================ ]]

if SERVER then
    AddCSLuaFile()
end

TBH = TBH or {}

TBH.Version = "1.0.0"
TBH.NetString = "hotloader"

--------------------------------------------------------------------------------
-- Theme (neon dark green)
--------------------------------------------------------------------------------

TBH.Colors = {
    tag      = Color(124, 211, 78),   -- bright steam green
    accent   = Color(94, 168, 62),    -- mid green
    dim      = Color(58, 104, 44),    -- deep green
    text     = Color(226, 234, 226),
    textdim  = Color(148, 160, 148),
    bg       = Color(16, 20, 17),
    bgPanel  = Color(26, 33, 27),
    bgPanel2 = Color(34, 43, 36),
    outline  = Color(52, 70, 55),
    error    = Color(236, 100, 100),
    warn     = Color(236, 184, 82),
    info     = Color(110, 176, 236),
    ok       = Color(124, 211, 78),
}

--------------------------------------------------------------------------------
-- Small shared utilities
--------------------------------------------------------------------------------

local string_find = string.find
local string_match = string.match
local string_gsub = string.gsub
local string_sub = string.sub
local string_gmatch = string.gmatch

function TBH.IsValidWSID(wsid)
    if not isstring(wsid) then return false end
    if #wsid < 6 or #wsid > 15 then return false end
    return string_match(wsid, "^%d+$") ~= nil
end

-- Extracts a workshop id from a raw id, a full workshop URL, or junk text
function TBH.ExtractWSID(input)
    if input == nil then return nil end
    if isnumber(input) then input = tostring(input) end
    if not isstring(input) then return nil end

    input = string_gsub(input, "^%s+", "")
    input = string_gsub(input, "%s+$", "")

    if input == "" then return nil end

    -- plain digits
    if string_match(input, "^%d+$") then
        if TBH.IsValidWSID(input) then return input end
        return nil
    end

    local id = string_match(input, "[?&]id=(%d+)")
    if not id then id = string_match(input, "/(%d+)/?$") end
    if not id then id = string_match(input, "/(%d+)") end

    if id and TBH.IsValidWSID(id) then return id end
    return nil
end

function TBH.WorkshopURL(wsid)
    return "https://steamcommunity.com/sharedfiles/filedetails/?id=" .. tostring(wsid)
end

-- Extracts map names ("gm_construct" from "maps/gm_construct.bsp") from a
-- mounted file list. Capped so a map-pack with 300 maps doesn't explode the
-- net message (300 maps still works, 255 is the UInt8 cap).
function TBH.ExtractMaps(files)
    local maps = {}

    for i = 1, #files do
        local mapname = string_match(files[i], "^maps/([%w_%-%.]+)%.bsp$")

        if mapname then
            maps[#maps + 1] = mapname

            if #maps >= 255 then break end
        end
    end

    return maps
end

-- Console printing helpers
function TBH.Msg(msg, color)
    MsgC(TBH.Colors.tag, "[Hotloader] ", color or TBH.Colors.text, msg .. "\n")
end

function TBH.LogError(msg)
    TBH.Msg(msg, TBH.Colors.error)
end

-- Shared notification + chat message (client realm only does the visuals)
-- duration: seconds the on-screen notification stays (default 6)
function TBH.NotifyLocally(msg, level, duration)
    if SERVER then
        local color = TBH.Colors.text
        if level == 1 then color = TBH.Colors.ok end
        if level == 2 then color = TBH.Colors.error end
        if level == 3 then color = TBH.Colors.warn end
        TBH.Msg(msg, color)
        return
    end

    -- CLIENT
    local ntype = NOTIFY_GENERIC
    if level == 2 then ntype = NOTIFY_ERROR end

    local secs = isnumber(duration) and math.Clamp(duration, 1, 30) or 6

    notification.AddLegacy("[Hotloader] " .. msg, ntype, secs)
    MsgC(TBH.Colors.tag, "[Hotloader] ", TBH.Colors.text, msg .. "\n")

    if level == 1 then surface.PlaySound("buttons/bell1.wav") end
    if level == 2 then surface.PlaySound("buttons/button10.wav") end

    -- keep a rolling log for the spawnmenu activity feed
    TBH.StatusLog = TBH.StatusLog or {}
    TBH.StatusLog[#TBH.StatusLog + 1] = { msg = msg, level = level or 0 }

    if #TBH.StatusLog > 40 then
        table.remove(TBH.StatusLog, 1)
    end

    hook.Run("TBH.StatusLogged", msg, level)
end

--------------------------------------------------------------------------------
-- ConVars
--------------------------------------------------------------------------------

local function GetOrCreateConVar(name, default, flags, help)
    if SERVER then
        return GetConVar(name) or CreateConVar(name, default, flags or { FCVAR_ARCHIVE, FCVAR_NOTIFY }, help or "")
    end
    return GetConVar(name) or CreateClientConVar(name, default, true, false, help or "")
end

-- Server settings (server-side archive convars)
TBH.CVarPermission  = SERVER and (GetConVar("tbh_permission") or CreateConVar("tbh_permission", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY }, "Who can hotload: 0 everyone, 1 admins, 2 superadmins")) or nil
TBH.CVarRequirements = SERVER and (GetConVar("tbh_requirements") or CreateConVar("tbh_requirements", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY }, "Automatically hotload an addon's Required Items")) or nil
TBH.CVarMaxFiles    = SERVER and (GetConVar("tbh_max_files") or CreateConVar("tbh_max_files", "20000", { FCVAR_ARCHIVE }, "Maximum files per hotloaded addon")) or nil
TBH.CVarTimeout     = SERVER and (GetConVar("tbh_timeout") or CreateConVar("tbh_timeout", "180", { FCVAR_ARCHIVE }, "Download watchdog timeout in seconds")) or nil
TBH.CVarCooldown    = SERVER and (GetConVar("tbh_cooldown") or CreateConVar("tbh_cooldown", "10", { FCVAR_ARCHIVE }, "Per-player hotload request cooldown in seconds")) or nil
TBH.CVarMaxQueue    = SERVER and (GetConVar("tbh_max_queue") or CreateConVar("tbh_max_queue", "10", { FCVAR_ARCHIVE }, "Maximum queued hotloads")) or nil
TBH.CVarLateSync    = SERVER and (GetConVar("tbh_latesync") or CreateConVar("tbh_latesync", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY }, "Sync hotloaded addons to players who join later")) or nil
TBH.CVarAnnounce    = SERVER and (GetConVar("tbh_announce") or CreateConVar("tbh_announce", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY }, "Chat announcements when addons get hotloaded")) or nil
TBH.CVarCleanupEmpty = SERVER and (GetConVar("tbh_cleanup_on_empty") or CreateConVar("tbh_cleanup_on_empty", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY }, "Wipe the hotload session registry when the last player leaves, so a new session starts completely clean")) or nil

-- Client settings
if CLIENT then
    TBH.CVarHints = GetOrCreateConVar("tbh_hints", "1", nil, "Show Hotloader welcome hints")
    TBH.CVarLogs  = GetOrCreateConVar("tbh_logs", "0", nil, "Verbose hotload logs in console")
    TBH.CVarAutoSubscribe = GetOrCreateConVar("tbh_autosubscribe", "1", nil, "Subscribing to a new Workshop addon in-game automatically requests a hotload")
    TBH.CVarEnableAddons = GetOrCreateConVar("tbh_enableaddons", "1", nil, "Enabling a disabled addon from the Addons menu automatically requests a hotload (the addon is already downloaded, so this is fast)")
end

--------------------------------------------------------------------------------
-- Net layer
-- All traffic rides a single network string with a sub-message name header.
--------------------------------------------------------------------------------

TBH.Net = { Receivers = {} }

if SERVER then
    util.AddNetworkString(TBH.NetString)
end

net.Receive(TBH.NetString, function(len, ply)
    local name = net.ReadString()
    local receiver = TBH.Net.Receivers[name]
    if receiver then
        local ok, err = pcall(receiver, len, ply)
        if not ok then
            ErrorNoHalt("[Hotloader] net receiver '" .. tostring(name) .. "' failed: " .. tostring(err) .. "\n")
        end
    end
end)

function TBH.Net:Receive(name, callback)
    self.Receivers[name] = callback
end

function TBH.Net:Start(name)
    net.Start(TBH.NetString)
    net.WriteString(name)
end

--------------------------------------------------------------------------------
-- gmsv_workshop module detection (SERVER realm only)
--
-- The gmsv_workshop module (by WilliamVenner) gives DEDICATED servers the
-- steamworks.DownloadUGC + steamworks.FileInfo functions. It is loaded with
-- require("workshop") which looks for gmsv_workshop_<arch>.dll in
-- garrysmod/lua/bin (win32/win64/linux/linux64 builds exist).
--
-- Clients and listen servers can always download natively.
--------------------------------------------------------------------------------

if SERVER then
    TBH.ServerCanUGC = (steamworks ~= nil and isfunction(steamworks.DownloadUGC))

    if not TBH.ServerCanUGC then
        local ok = pcall(require, "workshop")
        TBH.ServerCanUGC = ok and steamworks ~= nil and isfunction(steamworks.DownloadUGC)
        TBH.ModuleRequired = not TBH.ServerCanUGC -- remember that we tried and failed
    end

    TBH.ServerCanFileInfo = (steamworks ~= nil and isfunction(steamworks.FileInfo))
end


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  BUNDLE SYSTEM
--
--  A "bundle" is one hotloaded addon (or a group of requirement addons).
--  It re-implements what the engine does at boot, but mid-game:
--
--    * Runs lua/autorun, lua/autorun/server, lua/autorun/client
--    * Registers ENT / SWEP / EFFECT / PANEL classes
--    * Registers toolgun STOOLs into gmod_tool (and player toolguns)
--    * Simulates gamemode lifecycle hooks (Initialize, InitPostEntity, ...)
--    * Fakes "no players/entities yet" during init like a fresh boot
--    * Sandboxes hook/timer/include/require/AddCSLuaFile/module so the
--      bundle can be tracked, and so re-loads do not fight each other
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

do
    local Bundle = {}
    Bundle.__index = Bundle
    TBH.Bundle = Bundle

    local file_Read = file.Read
    local isLinux = system.IsLinux()

    local BundleCounter = 0

    local ClassTypes = {
        entities = { Global = "ENT", Table = scripted_ents, Count = 2 },
        weapons  = { Global = "SWEP", Table = weapons, Count = 3 },
    }

    if CLIENT then
        ClassTypes.effects = { Global = "EFFECT", Table = effects, Count = 2 }
        ClassTypes.vgui    = { Global = "PANEL", Table = vgui, Count = 2 }
    end

    local function IsClientClassType(typename)
        return typename == "vgui" or typename == "effects"
    end

    ------------------------------------------------------------------------
    -- Hook tracking
    ------------------------------------------------------------------------

    function Bundle:GIDHook(event, identifier)
        return "TBH." .. tostring(self.ID) .. "." .. event .. "." .. tostring(identifier)
    end

    function Bundle:AddHook(event, identifier, callback)
        local ev = self.Hooks[event]
        if not ev then
            ev = {}
            self.Hooks[event] = ev
        end

        ev[identifier] = callback

        local gid = self:GIDHook(event, identifier)
        self.HookGIDs[event .. "\1" .. tostring(identifier)] = gid

        hook.Add(event, gid, callback)
    end

    function Bundle:RemoveHook(event, identifier)
        local key = event .. "\1" .. tostring(identifier)
        local gid = self.HookGIDs[key]

        if gid then
            hook.Remove(event, gid)
            self.HookGIDs[key] = nil
        end

        if self.Hooks[event] then
            self.Hooks[event][identifier] = nil
        end
    end

    function Bundle:CallHooks(event, ...)
        local ev = self.Hooks[event]
        if not ev then return end

        for identifier, callback in pairs(ev) do
            local ok, err = pcall(callback, ...)
            if not ok then
                self:Error("hook '" .. tostring(event) .. "' [" .. tostring(identifier) .. "]: " .. tostring(err))
            end
        end
    end

    ------------------------------------------------------------------------
    -- Timer tracking (namespaced so bundles cannot nuke foreign timers)
    ------------------------------------------------------------------------

    function Bundle:TimerGID(name)
        return "TBH." .. tostring(self.ID) .. ".timer." .. tostring(name)
    end

    ------------------------------------------------------------------------
    -- The sandboxed environment
    ------------------------------------------------------------------------

    function Bundle:BuildEnvironment()
        local bundle = self
        local env = {}

        ----------------------------------------------------------------
        -- hook sandbox
        ----------------------------------------------------------------
        local hookSandbox = setmetatable({}, { __index = hook })

        function hookSandbox.Add(event, identifier, callback, ...)
            if not isstring(event) or not isstring(identifier) then return end
            if callback == nil then return bundle:RemoveHook(event, identifier) end
            if not isfunction(callback) then return end
            bundle:AddHook(event, identifier, callback)
        end

        function hookSandbox.Remove(event, identifier, ...)
            if not isstring(event) or not isstring(identifier) then return end
            bundle:RemoveHook(event, identifier)
        end

        function hookSandbox.GetTable()
            -- merged view: real table plus this bundle's entries under
            -- their original identifiers
            local real = hook.GetTable()
            local merged = {}

            for event, tab in pairs(real) do
                local copy = {}
                for id, fn in pairs(tab) do copy[id] = fn end
                merged[event] = copy
            end

            for event, tab in pairs(bundle.Hooks) do
                if not merged[event] then merged[event] = {} end
                for id, fn in pairs(tab) do
                    merged[event][id] = fn
                end
            end

            return merged
        end

        env.hook = hookSandbox

        ----------------------------------------------------------------
        -- timer sandbox
        ----------------------------------------------------------------
        local timerSandbox = setmetatable({}, { __index = timer })

        function timerSandbox.Create(name, delay, reps, func, ...)
            if name == nil then return timer.Create(name, delay, reps, func, ...) end
            local gid = bundle:TimerGID(name)
            bundle.Timers[tostring(name)] = gid
            return timer.Create(gid, delay, reps, func, ...)
        end

        function timerSandbox.Remove(name)
            local gid = bundle.Timers[tostring(name)]
            if gid then
                timer.Remove(gid)
                bundle.Timers[tostring(name)] = nil
                return
            end
            return timer.Remove(name)
        end

        function timerSandbox.Exists(name)
            local gid = bundle.Timers[tostring(name)]
            if gid and timer.Exists(gid) then return true end
            return timer.Exists(name)
        end

        env.timer = timerSandbox

        ----------------------------------------------------------------
        -- include / AddCSLuaFile / CompileFile / require / module
        ----------------------------------------------------------------
        env.include = function(path)
            -- note: do NOT tail-call - getfenv() cannot walk through tail
            -- call frames and Bundle:Include inspects the call stack
            local result = bundle:Include(path)
            return result
        end

        env.IncludeCS = function(path)
            if SERVER then
                bundle:AddCSLuaFileSandboxed(path)
            end
            local result = bundle:Include(path)
            return result
        end

        env.AddCSLuaFile = function(path, ...)
            bundle:AddCSLuaFileSandboxed(path)
        end

        env.CompileFile = function(path)
            local result = bundle:CompileFileSandboxed(path)
            return result
        end

        env.require = function(name, ...)
            local modpath = "includes/modules/" .. tostring(name) .. ".lua"
            local body = file_Read(modpath, "LUA") or file_Read("lua/" .. modpath, "GAME")

            if body then
                return bundle:InitializeFile(modpath)
            end

            return _G.require(name, ...)
        end

        env.module = function(name, ...)
            local callingEnv = getfenv(2)
            local moduleEnv = { TBH_IsModule = true }

            local hasSeeAll = false
            local loaders = { ... }
            for i = 1, #loaders do
                if loaders[i] == package.seeall then
                    hasSeeAll = true
                    break
                end
            end

            local M = _G[name]
            M = (istable(M) and M) or {}

            setmetatable(moduleEnv, {
                __index = function(_, key)
                    if hasSeeAll and callingEnv[key] ~= nil then
                        return callingEnv[key]
                    end
                    return M[key]
                end,
                __newindex = function(_, key, value)
                    M[key] = value
                end,
            })

            setfenv(2, moduleEnv)
            _G[name] = M
        end

        ----------------------------------------------------------------
        -- "Fresh boot" fakes until InitPostEntity is simulated.
        -- Many addons cache players/entities at load time and expect a
        -- fresh world; give them the boot-time view.
        ----------------------------------------------------------------
        local function PostInitFake(func, retval)
            return function(...)
                if not bundle.InitPostEntity then
                    if retval == "emptytable" then return {} end
                    return retval
                end
                return func(...)
            end
        end

        if CLIENT then
            local realEntity = Entity

            env.Player = PostInitFake(Player, NULL)
            env.LocalPlayer = PostInitFake(LocalPlayer, NULL)

            env.Entity = function(...)
                if bundle.InitPostEntity then return realEntity(...) end
                local ent = realEntity(...)
                if IsValid(ent) and ent:IsPlayer() then return NULL end
                return ent
            end

            local playerSandbox = setmetatable({
                GetAll         = PostInitFake(player.GetAll, "emptytable"),
                GetHumans      = PostInitFake(player.GetHumans, "emptytable"),
                GetCount       = PostInitFake(player.GetCount, 0),
                GetByAccountID = PostInitFake(player.GetByAccountID, false),
                GetBySteamID   = PostInitFake(player.GetBySteamID, false),
                GetBySteamID64 = PostInitFake(player.GetBySteamID64, false),
                GetByUniqueID  = PostInitFake(player.GetByUniqueID, false),
            }, { __index = player })

            env.player = playerSandbox
        end

        local entsSandbox = setmetatable({
            GetAll   = PostInitFake(ents.GetAll, "emptytable"),
            GetCount = PostInitFake(ents.GetCount, 0),
        }, { __index = ents })

        env.ents = entsSandbox

        ----------------------------------------------------------------
        -- Global fallback: reads fall through to _G, writes go to _G
        -- (same behavior as a normally loaded addon)
        ----------------------------------------------------------------
        setmetatable(env, {
            __index = function(_, key)
                return _G[key]
            end,
            __newindex = function(_, key, value)
                rawset(env, key, value)
                _G[key] = value
            end,
        })

        self.Environment = env
    end

    ------------------------------------------------------------------------
    -- Bundle creation
    ------------------------------------------------------------------------

    function Bundle:Create(files, name)
        BundleCounter = BundleCounter + 1

        local bundle = setmetatable({}, Bundle)

        bundle.ID = BundleCounter
        bundle.Name = name or "unknown"
        bundle.Files = {}
        bundle.FlatFiles = files or {}
        bundle.Hooks = {}
        bundle.HookGIDs = {}
        bundle.Timers = {}
        bundle.Errors = {}
        bundle.InitPostEntity = false
        bundle.LoadMapNav = false
        bundle.Unloaded = false
        bundle.RegisteredClasses = {
            entities = {},
            weapons = {},
            effects = {},
            vgui = {},
        }

        bundle.Information = {
            models = 0,
            materials = 0,
            lua = 0,
            sound = 0,
            other = 0,
        }

        bundle:BuildEnvironment()
        bundle:BuildFileTree(files or {})

        return bundle
    end

    ------------------------------------------------------------------------
    -- File tree (directories -> nested tables, files -> array entries)
    ------------------------------------------------------------------------

    function Bundle:BuildFileTree(files)
        for i = 1, #files do
            local filename = files[i]
            local folder = string_match(filename, "^%w+")

            if folder then
                local bucket = self.Information[folder]
                if bucket then
                    self.Information[folder] = bucket + 1
                else
                    self.Information.other = self.Information.other + 1
                end
            end

            if SERVER then
                if not self.LoadMapNav and filename == ("maps/" .. game.GetMap() .. ".nav") then
                    self.LoadMapNav = true
                end
            elseif CLIENT then
                if folder == "resource" and string_match(filename, "%.properties$") then
                    TBH.ParsePropertiesFile(filename)
                end
            end

            if folder == "lua" or folder == "gamemodes" then
                local dirs = string.Explode("/", filename)
                local curdir = self.Files

                for j = 1, #dirs do
                    local name = dirs[j]

                    if string_sub(name, -4) == ".lua" then
                        curdir[#curdir + 1] = name
                    else
                        if not curdir[name] then
                            curdir[name] = {}
                        end
                        curdir = curdir[name]
                    end
                end
            end
        end
    end

    ------------------------------------------------------------------------
    -- Tree queries
    ------------------------------------------------------------------------

    function Bundle:Find(...)
        local dirs = { ... }
        local curdir = self.Files

        for i = 1, #dirs do
            local name = dirs[i]
            if curdir[name] then
                curdir = curdir[name]
            else
                curdir = nil
                break
            end
        end

        local files, folders = {}, {}

        if curdir then
            for key, value in pairs(curdir) do
                if istable(value) then
                    folders[#folders + 1] = key
                else
                    files[#files + 1] = value
                end
            end

            table.sort(files, function(a, b)
                -- match engine load order per platform
                if isLinux then
                    return a > b
                end
                return a < b
            end)
        end

        return files, folders
    end

    function Bundle:DeepFind(...)
        local files, dirs = self:Find(...)

        if files[1] == nil and dirs[1] == nil then
            files, dirs = self:Find("gamemodes", engine.ActiveGamemode(), "entities", ...)
        end

        return files, dirs
    end

    ------------------------------------------------------------------------
    -- include() path resolution: walk the call stack, find the calling
    -- file's folder, try relative includes, canonize ../ segments
    ------------------------------------------------------------------------

    function Bundle:GetAbsolutePath(path)
        if not isstring(path) then return path end

        for i = 2, 15 do
            local callst = debug.getinfo(i, "S")
            if not callst then break end

            local source = callst.source or ""
            local _, endpos = string_find(source, "lua/")

            if endpos then
                source = string_sub(source, endpos + 1)

                local lastSlash = string_match(source, "^.*/")
                if lastSlash then
                    source = lastSlash
                else
                    source = ""
                end

                local fixedPath = source .. path

                -- canonize foo/../ away
                while string_find(fixedPath, "../", 1, true) do
                    local canonized = string_gsub(fixedPath, "[%w%._]+/../", "")
                    if canonized == fixedPath then break end
                    fixedPath = canonized
                end

                if file_Read(fixedPath, "LUA") or file_Read(fixedPath, "GAME") or file_Read("lua/" .. fixedPath, "GAME") then
                    return fixedPath
                elseif source == "autorun/client/" or source == "autorun/server/" then
                    -- autorun realm folders can include from autorun/ root
                    local canonized = "autorun/" .. path
                    if file_Read(canonized, "LUA") or file_Read(canonized, "GAME") or file_Read("lua/" .. canonized, "GAME") then
                        return canonized
                    end
                end
            end
        end

        return path
    end

    ------------------------------------------------------------------------
    -- Compiling + running files
    ------------------------------------------------------------------------

    function Bundle:CompileChunk(relpath)
        local fullpath = "lua/" .. relpath
        local body = file_Read(fullpath, "GAME") or file_Read(fullpath, "LUA")

        if not body then
            self:Error("attempted to compile a missing file: " .. fullpath)
            return nil
        end

        local fn = CompileString(body, fullpath)

        if not isfunction(fn) then
            self:Error("syntax error while compiling " .. fullpath)
            return nil
        end

        return setfenv(fn, self.Environment)
    end

    function Bundle:InitializeFile(relpath)
        local fn = self:CompileChunk(relpath)
        if not fn then return end

        local results = { pcall(fn) }

        if not results[1] then
            self:Error(tostring(results[2]))
            return
        end

        return unpack(results, 2)
    end

    function Bundle:Include(path)
        local compiled = self:CompileChunk(self:GetAbsolutePath(path))
        if not compiled then return end

        -- if include() was called inside a module() environment, keep it
        for i = 2, 16 do
            if not debug.getinfo(i, "f") then break end

            -- getfenv can throw on tail-call frames - guard it
            local okEnv, fenv = pcall(getfenv, i)

            if okEnv and istable(fenv) and rawget(fenv, "TBH_IsModule") then
                setfenv(compiled, fenv)
                break
            end
        end

        local results = { pcall(compiled) }

        if not results[1] then
            self:Error(tostring(results[2]))
            return
        end

        return unpack(results, 2)
    end

    function Bundle:CompileFileSandboxed(path)
        local fn = self:CompileChunk(self:GetAbsolutePath(path))
        if fn then
            return fn
        end
    end

    function Bundle:AddCSLuaFileSandboxed(path)
        local absolute

        if path == nil then
            local src = debug.getinfo(2, "S").source
            local _, endpos = string_find(src, "lua/")

            if endpos then
                local rel = string_sub(src, endpos + 1)
                if file_Read(rel, "LUA") or file_Read("lua/" .. rel, "GAME") then
                    absolute = rel
                end
            end
        end

        if not absolute then
            absolute = self:GetAbsolutePath(path)
        end

        if absolute then
            local ok, err = pcall(_G.AddCSLuaFile, absolute)
            if not ok then
                self:Error("AddCSLuaFile('" .. tostring(absolute) .. "') failed: " .. tostring(err))
            end
        end
    end

    ------------------------------------------------------------------------
    -- Error collection
    ------------------------------------------------------------------------

    function Bundle:Error(msg)
        msg = string_sub(tostring(msg), 1, 400)
        self.Errors[#self.Errors + 1] = msg
    end

    function Bundle:Message(msg)
        if SERVER then
            if game.IsDedicated() then
                MsgC(TBH.Colors.tag, "[Hotloader] ", TBH.Colors.textdim, msg .. "\n")
            end
        else
            if TBH.CVarLogs and TBH.CVarLogs:GetBool() then
                MsgC(TBH.Colors.tag, "[Hotloader] ", TBH.Colors.textdim, msg .. "\n")
            end
        end
    end

    ------------------------------------------------------------------------
    -- autorun initialization
    ------------------------------------------------------------------------

    function Bundle:InitializeAutorun()
        local function InitializeFolder(...)
            local filelist = self:Find("lua", ...)

            for i = 1, #filelist do
                self:InitializeFile(table.concat({ ... }, "/") .. "/" .. filelist[i])
            end
        end

        InitializeFolder("autorun")

        if SERVER then
            InitializeFolder("autorun", "server")
        else
            InitializeFolder("autorun", "client")
        end
    end

    ------------------------------------------------------------------------
    -- ENT / SWEP / EFFECT / PANEL registration
    ------------------------------------------------------------------------

    local function CreateNewClass(classtype)
        local dat = ClassTypes[classtype]
        if not dat then return end

        local CLASS = {}

        if classtype == "weapons" then
            CLASS.Primary = {}
            CLASS.Secondary = {}
        end

        _G[dat.Global] = CLASS

        return dat.Global, dat.Table, dat.Count
    end

    local function RegisterNewClass(classtype, classname, tblname, basetable, registercount, bundle)
        local CLASS = _G[tblname]

        if CLASS and table.Count(CLASS) >= registercount then
            if classtype == "vgui" then
                if not basetable.GetControlTable(classname) then
                    basetable.Register(classname, CLASS, CLASS.Base)
                end
            else
                if basetable.Register then
                    local ok = pcall(basetable.Register, CLASS, classname)
                    if not ok then
                        -- try again as (name, table) order used by some libs
                        pcall(basetable.Register, classname, CLASS)
                    end

                    if not IsClientClassType(classtype) and basetable.Get then
                        timer.Simple(0.1, function()
                            baseclass.Set(classname, basetable.Get(classname))
                        end)
                    end
                end
            end

            -- remember what we registered so a soft unload can remove it
            if bundle and istable(bundle.RegisteredClasses) then
                local list = bundle.RegisteredClasses[classtype]
                if list then
                    list[#list + 1] = classname
                end
            end
        end

        _G[tblname] = nil
    end

    function Bundle:InitializeScriptedClasses(classtype)
        local dat = ClassTypes[classtype]
        if not dat then return end

        local files, dirs = self:DeepFind("lua", classtype)

        -- single file classes: lua/entities/foo.lua
        for i = 1, #files do
            local filename = files[i]
            local classname = string_sub(filename, 1, -5)
            local tblname, basetable, registercount = CreateNewClass(classtype)

            _G[tblname].Folder = classtype .. "/" .. classname
            self:InitializeFile(classtype .. "/" .. filename)

            RegisterNewClass(classtype, classname, tblname, basetable, registercount, self)
        end

        -- folder classes: lua/entities/foo/init.lua + cl_init.lua + shared.lua
        for i = 1, #dirs do
            local classname = dirs[i]

            if classtype ~= "weapons" or classname ~= "gmod_tool" then
                local files = self:DeepFind("lua", classtype, classname)
                local tblname, basetable, registercount = CreateNewClass(classtype)

                _G[tblname].Folder = classtype .. "/" .. classname

                for j = 1, #files do
                    local filename = files[j]
                    local path = classtype .. "/" .. classname .. "/" .. filename

                    if filename == "init.lua" and (SERVER or IsClientClassType(classtype)) then
                        self:InitializeFile(path)
                    elseif filename == "cl_init.lua" and CLIENT then
                        self:InitializeFile(path)
                    elseif filename == "shared.lua" then
                        self:InitializeFile(path)
                    end
                end

                RegisterNewClass(classtype, classname, tblname, basetable, registercount, self)
            end
        end
    end

    ------------------------------------------------------------------------
    -- Toolgun STOOL registration
    ------------------------------------------------------------------------

    function Bundle:InitializeTools()
        local GM = gmod.GetGamemode()

        if not GM or not GM.IsSandboxDerived then
            return
        end

        local tools = self:DeepFind("lua", "weapons", "gmod_tool", "stools")

        if #tools == 0 then return end

        local players = player.GetAll()

        local toolSWEP = weapons.GetStored("gmod_tool")

        if not toolSWEP or not toolSWEP.Tool then
            return
        end

        local axisTool = toolSWEP.Tool and toolSWEP.Tool.axis
        local ToolObj = axisTool and getmetatable(axisTool)

        if not ToolObj then
            return
        end

        local oldSWEP, oldTOOL, oldToolObj = _G.SWEP, _G.TOOL, _G.ToolObj

        _G.SWEP = toolSWEP
        _G.ToolObj = ToolObj

        for i = 1, #tools do
            local filename = tools[i]
            local toolname = string_sub(filename, 1, -5)

            local TOOL = ToolObj:Create()
            TOOL.Mode = toolname

            _G.TOOL = TOOL
            self:InitializeFile("weapons/gmod_tool/stools/" .. filename)
            _G.TOOL = TOOL -- re-set in case the stool file cleared it

            local ok = pcall(function() TOOL:CreateConVars() end)
            if not ok then
                self:Error("stool '" .. toolname .. "' CreateConVars failed")
            end

            toolSWEP.Tool[toolname] = TOOL

            -- push the tool into every player's live toolgun
            for k, ply in ipairs(players) do
                local toolgun = ply:GetWeapon("gmod_tool")

                if IsValid(toolgun) and toolgun.Tool then
                    local tool = table.Copy(TOOL)

                    tool.SWEP = toolgun
                    tool.Weapon = toolgun
                    tool.Owner = ply

                    local okInit = pcall(function() tool:Init() end)
                    if okInit then
                        toolgun.Tool[toolname] = tool
                    end
                end
            end
        end

        _G.SWEP = oldSWEP
        _G.TOOL = oldTOOL
        _G.ToolObj = oldToolObj

        -- remember for the menu/UI
        TBH.LoadedTools = TBH.LoadedTools or {}
        for i = 1, #tools do
            local toolname = string_sub(tools[i], 1, -5)
            TBH.LoadedTools[toolname] = true
        end
    end

    ------------------------------------------------------------------------
    -- Soft unload: strips everything this bundle's Lua is doing.
    --
    -- CAN remove: hooks, timers, spawnmenu list entries, spawned entities
    --             (optional), held weapons of the addon's classes.
    -- CANNOT remove: the class tables inside weapons/scripted_ents (no
    --             unregister API exists - we hide them from the spawnmenu
    --             instead), and the mounted FILES themselves (GMod simply
    --             has no unmount API - a binary module would be required).
    ------------------------------------------------------------------------

    function Bundle:Unload(removeEntities)
        if self.Unloaded then return end
        self.Unloaded = true

        -- 1. hooks
        for key, gid in pairs(self.HookGIDs) do
            local event = string_match(key, "^(.-)\1")
            if event then
                hook.Remove(event, gid)
            end
        end

        self.HookGIDs = {}
        self.Hooks = {}

        -- 2. timers
        for name, gid in pairs(self.Timers) do
            timer.Remove(gid)
        end

        self.Timers = {}

        -- 3. spawnmenu entries (hide from the menus even though the class
        --    tables technically remain registered)
        local entityClasses = self.RegisteredClasses.entities or {}
        local weaponClasses = self.RegisteredClasses.weapons or {}

        for i = 1, #entityClasses do
            pcall(function()
                list.RemoveEntry("SpawnableEntities", entityClasses[i])
                list.RemoveEntry("SpawnableSent", entityClasses[i])
            end)
        end

        for i = 1, #weaponClasses do
            pcall(function()
                list.RemoveEntry("Weapon", weaponClasses[i])
                list.RemoveEntry("SpawnableWeapons", weaponClasses[i])
            end)
        end

        -- 4. optionally remove entities the addon's classes spawned
        if SERVER and removeEntities then
            for i = 1, #entityClasses do
                local classname = entityClasses[i]

                for _, ent in ipairs(ents.FindByClass(classname)) do
                    if IsValid(ent) then
                        ent:Remove()
                    end
                end
            end

            -- strip held weapons of the addon's classes
            for i = 1, #weaponClasses do
                local classname = weaponClasses[i]

                for _, ply in ipairs(player.GetAll()) do
                    local wep = ply:GetWeapon(classname)

                    if IsValid(wep) then
                        ply:StripWeapon(classname)
                    end
                end
            end
        end

        if CLIENT then
            -- refresh the spawnmenu so the hidden entries disappear
            RunConsoleCommand("spawnmenu_reload")
        end

        hook.Run("TBH.BundleUnloaded", self)
    end

    ------------------------------------------------------------------------
    -- Full staged initialization (mirrors a fresh game boot)
    ------------------------------------------------------------------------

    function Bundle:Initialize()
        local savedENT, savedSWEP, savedPANEL, savedEFFECT =
            _G.ENT, _G.SWEP, _G.PANEL, _G.EFFECT

        ProtectedCall(function()
            local time = SysTime()

            self:Message("[" .. self.Name .. "] initializing (" .. (SERVER and "server" or "client") .. ")...")

            self:InitializeAutorun()
            self:InitializeScriptedClasses("vgui")
            self:InitializeScriptedClasses("weapons")
            self:InitializeTools()
            self:InitializeScriptedClasses("entities")
            self:InitializeScriptedClasses("effects")

            -- simulate the gamemode lifecycle that already happened
            self:CallHooks("PreGamemodeLoaded")
            self:CallHooks("OnGamemodeLoaded")
            self:CallHooks("PostGamemodeLoaded")
            self:CallHooks("Initialize")

            self.InitPostEntity = true

            self:CallHooks("InitPostEntity")

            if SERVER then
                local callbacks = self.Hooks.PlayerInitialSpawn
                if callbacks and not table.IsEmpty(callbacks) then
                    for k, ply in ipairs(player.GetAll()) do
                        self:CallHooks("PlayerInitialSpawn", ply, false)
                    end
                end
            end

            local hookcount = 0
            for event, tab in pairs(self.Hooks) do
                hookcount = hookcount + table.Count(tab)
            end

            time = math.Round(SysTime() - time, 3)

            self:Message(string.format(
                "[%s] initialized in %s seconds - %d hooks, %d lua files, %d models, %d materials, %d sounds",
                self.Name, tostring(time), hookcount,
                self.Information.lua, self.Information.models,
                self.Information.materials, self.Information.sound
            ))

            hook.Run("TBH.BundleInitialized", self)
        end)

        if SERVER then
            if navmesh and navmesh.IsLoaded and not navmesh.IsLoaded() and self.LoadMapNav then
                navmesh.Load()
            end
        end

        _G.ENT = savedENT
        _G.SWEP = savedSWEP
        _G.PANEL = savedPANEL
        _G.EFFECT = savedEFFECT

        -- post-init reporting
        timer.Simple(1, function()
            if CLIENT then
                RunConsoleCommand("spawnmenu_reload")
            end

            if self.Errors[1] ~= nil then
                local realm = SERVER and "SERVER" or "CLIENT"
                local errors = table.concat(self.Errors, "\n")

                MsgC(TBH.Colors.warn, "\n[Hotloader] " .. realm .. " errors while hotloading '" .. self.Name .. "':\n")
                MsgC(TBH.Colors.textdim, string_sub(errors, 1, 4000) .. "\n\n")

                hook.Run("TBH.BundleErrored", self, self.Errors)
            end
        end)
    end
end


--------------------------------------------------------------------------------
-- Workshop localization files (resource/localization/*.properties)
-- Lets hotloaded addons use #language.phrases like normally mounted ones.
--------------------------------------------------------------------------------

TBH.PropertiesTranslations = TBH.PropertiesTranslations or {}

function TBH.ParsePropertiesFile(filename)
    local body = file.Read(filename, "GAME")
    if not body then return end

    local lang = string_match(filename, "resource/localization/([%w_%-]+)/")
    if not lang then return end

    local translations = TBH.PropertiesTranslations[lang]
    if not translations then
        translations = {}
        TBH.PropertiesTranslations[lang] = translations
    end

    for k, line in ipairs(string.Explode("\n", body)) do
        local startpos, endpos, key = string.find(line, "([%w%-%._]+)%s*=%s*")

        if key then
            translations[key] = string_sub(line, endpos + 1)
        end
    end
end

if CLIENT then
    -- detour language.GetPhrase once (refresh-safe)
    if not TBH.LanguageDetoured then
        TBH.LanguageDetoured = true

        local language_GetPhrase = language.GetPhrase
        local gmod_language = GetConVar("gmod_language")

        function language.GetPhrase(phrase, ...)
            if isstring(phrase) then
                local lang = gmod_language and gmod_language:GetString() or "en"
                local translations = TBH.PropertiesTranslations[lang]

                if translations then
                    local translation = translations[string_sub(phrase, 2)]
                    if translation then
                        return translation
                    end
                end
            end

            return language_GetPhrase(phrase, ...)
        end
    end
end

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  RUNTIME AMMO TYPES
--
--  game.AddAmmoType does nothing after the game has booted, so hotloaded
--  weapons with custom ammo would have broken HUDs and no damage values.
--  This subsystem intercepts the ammo API and emulates ammo types with
--  NW2-backed counters, a reference ammo type for FireBullets, and full
--  compatibility wrappers for Give/Set/Get ammo and weapon ammo types.
--
--  (Approach adapted from Midgame Workshop Hotloader's sh_ammo.)
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

do
    local REF_AMMO = "_tbh_refammo_ammo"

    TBH.Detours = TBH.Detours or {}

    local function Detour(basetbl, key, detourName, func)
        local storeKey = detourName .. "." .. key
        local old = TBH.Detours[storeKey] or basetbl[key]

        if old then
            basetbl[key] = function(...)
                local retval = func(...)
                if retval ~= nil then
                    return retval
                end
                return old(...)
            end

            TBH.Detours[storeKey] = old
        end
    end

    -- Register the reference ammo type (only once per boot)
    if game.GetAmmoID(REF_AMMO) == -1 then
        game.AddAmmoType({ name = REF_AMMO })
    end

    timer.Simple(0.25, function()
        local ammoTypes = {}   -- [id] = ammoData
        local isTBHAmmo = {}   -- [name] = id

        local function GetAmmoData(any)
            if isnumber(any) then
                return ammoTypes[any]
            end
            if isstring(any) then
                local id = isTBHAmmo[any]
                if id then return ammoTypes[id] end
            end
        end

        local _R = debug.getregistry()

        local Entity = _R.Entity
        local Player = _R.Player

        if CLIENT then
            TBH.Net:Receive("tbh_ammo", function()
                hook.Run("HUDAmmoPickedUp", net.ReadString(), net.ReadInt(32))
                surface.PlaySound("items/ammo_pickup.wav")
            end)
        end

        local function QuickDetour(key, valuename)
            Detour(game, key, "game", function(id)
                local data = ammoTypes[id]
                if data then
                    return data[valuename]
                end
            end)
        end

        Detour(Player, "GiveAmmo", "Player", function(self, count, ammoType, hidePopup)
            local data = GetAmmoData(ammoType)
            if data then
                local keyname = "TBH_AmmoCount_" .. data.name
                local oldCount = self:GetNW2Int(keyname)

                self:SetNW2Int(keyname, oldCount + count)

                if not hidePopup then
                    TBH.Net:Start("tbh_ammo")
                    net.WriteString(data.name)
                    net.WriteInt(count, 32)
                    net.Send(self)
                end
            end
        end)

        Detour(Player, "RemoveAmmo", "Player", function(self, count, ammoName)
            local data = GetAmmoData(ammoName)
            if data then
                local keyname = "TBH_AmmoCount_" .. data.name
                local newCount = self:GetNW2Int(keyname) - count
                if newCount < 0 then newCount = 0 end

                self:SetNW2Int(keyname, newCount)
            end
        end)

        Detour(Player, "SetAmmo", "Player", function(self, count, ammoType)
            local data = GetAmmoData(ammoType)
            if data then
                self:SetNW2Int("TBH_AmmoCount_" .. data.name, count)
            end
        end)

        Detour(Player, "GetAmmoCount", "Player", function(self, ammoType)
            local data = GetAmmoData(ammoType)
            if data then
                return self:GetNW2Int("TBH_AmmoCount_" .. data.name)
            end
        end)

        Detour(Player, "GetAmmo", "Player", function(self)
            local GetAmmoOriginal = TBH.Detours["Player.GetAmmo"] or Player.GetAmmo
            local ammo = GetAmmoOriginal(self)
            if not istable(ammo) then ammo = {} end

            for id, ammoData in pairs(ammoTypes) do
                local ammoCount = self:GetNW2Int("TBH_AmmoCount_" .. ammoData.name)
                if ammoCount > 0 then
                    ammo[id] = ammoCount
                end
            end

            return ammo
        end)

        QuickDetour("GetAmmoMax", "maxcarry")
        QuickDetour("GetAmmoName", "name")
        QuickDetour("GetAmmoForce", "force")
        QuickDetour("GetAmmoNPCDamage", "npcdmg")
        QuickDetour("GetAmmoDamageType", "dmgtype")
        QuickDetour("GetAmmoPlayerDamage", "plydmg")

        do
            local game_GetAmmoTypes = game.GetAmmoTypes

            Detour(game, "GetAmmoTypes", "game", function()
                local gameAmmoTypes = game_GetAmmoTypes()
                for id, ammoData in pairs(ammoTypes) do
                    gameAmmoTypes[id] = ammoData.name
                end
                return gameAmmoTypes
            end)
        end

        do
            local Weapon = _R.Weapon
            local IsScripted = Weapon.IsScripted
            local IsValidFn = Entity.IsValid

            local function WeaponQuickDetour(key, ammoTabKey)
                Detour(Weapon, key, "Weapon", function(self)
                    local tab = self[ammoTabKey]
                    if (IsValidFn(self) and IsScripted(self)) and (tab and tab.Ammo) then
                        return isTBHAmmo[tab.Ammo]
                    end
                end)
            end

            WeaponQuickDetour("GetPrimaryAmmoType", "Primary")
            WeaponQuickDetour("GetSecondaryAmmoType", "Secondary")
        end

        Detour(game, "AddAmmoType", "game", function(ammoData)
            if not istable(ammoData) or not isstring(ammoData.name) then return end

            local name = ammoData.name

            if not isTBHAmmo[name] and game.GetAmmoID(name) == -1 then
                local id = #game.GetAmmoTypes() + 1
                ammoTypes[id] = ammoData
                isTBHAmmo[name] = id
                return true
            end
        end)

        Detour(game, "GetAmmoID", "game", function(name)
            if isstring(name) then
                return isTBHAmmo[name]
            end
        end)

        Detour(game, "GetAmmoData", "game", function(id)
            return ammoTypes[id]
        end)

        Detour(Entity, "FireBullets", "Entity", function(self, bulletData)
            local ammoType = bulletData.AmmoType
            local id = isTBHAmmo[ammoType]

            if id then
                local data = ammoTypes[id]
                bulletData.AmmoType = REF_AMMO
                bulletData.Tracer = data.tracer or bulletData.Tracer
                bulletData.Force = data.force or bulletData.Force
            end
        end)

        -- weapon pickup: hand out default clips for custom ammo types
        if SERVER and GAMEMODE ~= nil and isfunction(GAMEMODE.PlayerCanPickupWeapon) then
            Detour(GAMEMODE, "PlayerCanPickupWeapon", "GAMEMODE", function(self, ply, wep)
                if IsValid(wep) and wep:IsScripted() then
                    local primary = wep.Primary
                    local secondary = wep.Secondary

                    if istable(primary) and isTBHAmmo[primary.Ammo] and primary.DefaultClip then
                        ply:GiveAmmo(primary.DefaultClip, primary.Ammo)
                    end

                    if istable(secondary) and isTBHAmmo[secondary.Ammo] and secondary.DefaultClip then
                        ply:GiveAmmo(secondary.DefaultClip, secondary.Ammo)
                    end
                end
            end)
        end
    end)
end


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  WORKSHOP HELPERS
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

-- Reads the addon title straight out of a .gma file header
function TBH.GetGMATitle(path)
    local ok, title = pcall(function()
        local f = file.Open(path, "rb", "GAME")
        if not f then f = file.Open(path, "rb", "MOD") end
        if not f then return nil end

        local result = nil

        if f:Read(4) == "GMAD" then
            f:Skip(1)  -- version
            f:Skip(8)  -- steamid64
            f:Skip(8)  -- timestamp

            -- required content: null-terminated strings, ends with an empty one
            while not f:EndOfFile() do
                local str = {}
                local terminated = false

                while not f:EndOfFile() do
                    local c = f:Read(1)
                    if c == "\0" or c == "" or c == nil then
                        terminated = true
                        break
                    end
                    str[#str + 1] = c
                end

                -- an empty string marks the end of the required content block
                if terminated and #str == 0 then break end
                if f:EndOfFile() then break end
            end

            -- the addon title (null-terminated)
            local chars = {}
            while not f:EndOfFile() do
                local c = f:Read(1)
                if c == "\0" or c == "" or c == nil then break end
                chars[#chars + 1] = c
            end

            result = table.concat(chars)
        end

        f:Close()
        return result
    end)

    if ok then return title end
    return nil
end

-- Scrapes a Workshop page for its "Required Items" links, recursively
function TBH.GetRequiredAddons(wsid, callback, required, pending)
    required = required or {}
    pending = pending or {}

    pending[wsid] = true

    local function CheckDone()
        if next(pending) == nil then
            if isfunction(callback) then
                callback(table.GetKeys(required))
            end
        end
    end

    http.Fetch("https://steamcommunity.com/sharedfiles/filedetails/?id=" .. wsid, function(body)
        for id in string_gmatch(body, '<a href="https://steamcommunity%.com/workshop/filedetails/%?id=(%d+)" target="_blank">') do
            if not required[id] and table.Count(required) < 64 then
                required[id] = true
                TBH.GetRequiredAddons(id, callback, required, pending)
            end
        end

        pending[wsid] = nil
        CheckDone()
    end, function()
        pending[wsid] = nil
        CheckDone()
    end)
end

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  SERVER PIPELINE
--
--  request -> permission check -> (requirements) -> queue ->
--  DownloadUGC (gmsv_workshop) -> MountGMA -> server bundle init ->
--  broadcast to every player -> result tracking -> late-join sync
--
--  Listen servers without the module fall back to routing downloads
--  through the host player's client (chunked file-list transfer).
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

if SERVER then
    TBH.Server = {
        Queue = {},
        Current = nil,
        Mounted = {},
        FailedUntil = {},
        PlayerCooldown = {},
        HostBundles = {},
        HostPending = {},
        Sync = {},
    }

    --------------------------------------------------------------------
    -- Helpers
    --------------------------------------------------------------------

    local function StatusTo(ply, msg, level)
        if IsValid(ply) then
            TBH.Net:Start("status")
            net.WriteUInt(level or 0, 8)
            net.WriteString(string_sub(msg, 1, 220))
            net.Send(ply)
        else
            -- server console
            local color = TBH.Colors.text
            if level == 1 then color = TBH.Colors.ok end
            if level == 2 then color = TBH.Colors.error end
            if level == 3 then color = TBH.Colors.warn end
            TBH.Msg(msg, color)
        end
    end

    local function ChatBroadcast(msg, level, duration)
        if not TBH.CVarAnnounce:GetBool() then return end

        TBH.Net:Start("chatmsg")
        net.WriteUInt(level or 0, 8)
        net.WriteUInt(isnumber(duration) and math.Clamp(duration, 0, 30) or 0, 8)
        net.WriteString(string_sub(msg, 1, 240))
        net.Broadcast()
    end

    local function CanHotload(ply)
        if not IsValid(ply) then return true end
        if ply:IsListenServerHost() then return true end

        local lvl = TBH.CVarPermission:GetInt()

        if lvl <= 0 then return true end

        if lvl == 1 then
            if ply:IsAdmin() then return true end
            return false, "hotloading is admin-only (tbh_permission 1)"
        end

        if ply:IsSuperAdmin() then return true end
        return false, "hotloading is superadmin-only (tbh_permission 2)"
    end

    local function FindHostPlayer()
        for _, p in ipairs(player.GetAll()) do
            if p:IsListenServerHost() then return p end
        end
    end

    --------------------------------------------------------------------
    -- Mount + broadcast (shared by both download paths)
    --------------------------------------------------------------------

    local function WriteMaps(maps)
        local count = istable(maps) and math.min(#maps, 255) or 0
        net.WriteUInt(count, 8)

        for i = 1, count do
            net.WriteString(maps[i])
        end
    end

    local function FinalizeMount(wsid, title, files, requester, skipHost)
        local cleanFiles, seen = {}, {}
        for _, f in pairs(files) do
            if not seen[f] then
                seen[f] = true
                cleanFiles[#cleanFiles + 1] = f
            end
        end

        local maps = TBH.ExtractMaps(cleanFiles)

        local bundle = TBH.Bundle:Create(cleanFiles, title)
        bundle:Initialize()

        TBH.Server.Mounted[wsid] = {
            title = title,
            files = #cleanFiles,
            time = os.time(),
            errors = #bundle.Errors,
            maps = maps,
            bundle = bundle,
            unloaded = false,
        }

        -- tell every player to grab it too
        local targets, skippedHost = {}, false
        for _, p in ipairs(player.GetAll()) do
            if skipHost and p:IsListenServerHost() then
                skippedHost = true
            else
                targets[#targets + 1] = p
            end
        end

        if #targets > 0 then
            TBH.Net:Start("mount")
            net.WriteString(wsid)
            net.WriteString(title)
            WriteMaps(maps)
            net.Send(targets)
        end

        local mapInfo = ""

        if #maps > 0 then
            local preview = maps[1]
            if #maps > 1 then preview = preview .. " (+" .. (#maps - 1) .. " more)" end
            mapInfo = " - contains map \"" .. preview .. "\" - hit LOAD MAP in the Q menu!"
        end

        ChatBroadcast("Hotloaded \"" .. title .. "\" (" .. #cleanFiles .. " files)" .. mapInfo, 1)

        if #maps > 0 then
            StatusTo(requester, "\"" .. title .. "\" hotloaded! Map(s): " .. table.concat(maps, ", "), 1)
        else
            StatusTo(requester, "\"" .. title .. "\" hotloaded on the server!", 1)
        end

        -- result tracking (best effort summary after 90 seconds)
        TBH.Server.Sync[wsid] = { ok = 0, failed = 0, total = #targets, failedNames = {} }

        timer.Simple(90, function()
            local track = TBH.Server.Sync[wsid]
            if not track or track.reported then return end
            track.reported = true

            if track.failed > 0 then
                ChatBroadcast(track.failed .. "/" .. track.total .. " players failed to sync \"" .. title .. "\" (see server console)", 3)
            end
        end)

        hook.Run("TBH.ServerHotloaded", wsid, title, bundle)

        return bundle
    end

    --------------------------------------------------------------------
    -- Queue processing (module / native server download path)
    --------------------------------------------------------------------

    local function ProcessQueue()
        if TBH.Server.Current ~= nil then return end

        local entry = table.remove(TBH.Server.Queue, 1)
        if not entry then return end

        local wsid = entry.wsid
        local title = entry.title or wsid
        TBH.Server.Current = wsid

        local timeout = math.Clamp(TBH.CVarTimeout:GetInt(), 30, 900)
        local finished = false

        local function Finish(errMsg)
            if finished then return end
            finished = true

            timer.Remove("TBH.DL." .. wsid)
            TBH.Server.Current = nil

            if errMsg then
                TBH.Server.FailedUntil[wsid] = CurTime() + 60
                StatusTo(entry.requester, "Hotload of \"" .. title .. "\" failed: " .. errMsg, 2)
                TBH.LogError("Hotload of " .. wsid .. " failed: " .. errMsg)
            end

            timer.Simple(1, ProcessQueue)
        end

        timer.Create("TBH.DL." .. wsid, timeout, 1, function()
            Finish("download timed out after " .. timeout .. "s")
        end)

        StatusTo(entry.requester, "Downloading \"" .. title .. "\" on the server...", 0)
        TBH.Msg("Downloading workshop addon " .. wsid .. " (" .. title .. ")...")

        steamworks.DownloadUGC(wsid, function(path, gmaFile)
            if finished then return end

            if not path or not gmaFile then
                return Finish("download failed (addon hidden, removed, or Steam unreachable?)")
            end

            local ok, files = game.MountGMA(path)

            if not ok or not istable(files) then
                return Finish("game.MountGMA failed")
            end

            local maxFiles = TBH.CVarMaxFiles:GetInt()
            if #files > maxFiles then
                return Finish("addon has " .. #files .. " files (limit: " .. maxFiles .. ", raise tbh_max_files)")
            end

            local gmaTitle = TBH.GetGMATitle(path)
            if gmaTitle and #gmaTitle > 0 then
                title = gmaTitle
            end

            local okFinalize, errFinalize = pcall(FinalizeMount, wsid, title, files, entry.requester, false)
            if not okFinalize then
                TBH.LogError("FinalizeMount crashed: " .. tostring(errFinalize))
                StatusTo(entry.requester, "Hotload of \"" .. title .. "\" crashed during initialization (see server console)", 2)
            end

            Finish(nil)
        end)
    end

    --------------------------------------------------------------------
    -- Queueing + requirement chains
    --------------------------------------------------------------------

    local function Enqueue(wsid, title, requester)
        if #TBH.Server.Queue >= TBH.CVarMaxQueue:GetInt() then
            StatusTo(requester, "Hotload queue is full (" .. TBH.CVarMaxQueue:GetInt() .. ") - try again later", 3)
            return false
        end

        TBH.Server.Queue[#TBH.Server.Queue + 1] = {
            wsid = wsid,
            title = title,
            requester = requester,
        }

        return true
    end

    local function AlreadyKnown(wsid)
        if TBH.Server.Mounted[wsid] then
            return "already hotloaded (" .. (TBH.Server.Mounted[wsid].title or wsid) .. ")"
        end

        if TBH.Server.Current == wsid then
            return "already downloading right now"
        end

        for i = 1, #TBH.Server.Queue do
            if TBH.Server.Queue[i].wsid == wsid then
                return "already in the queue"
            end
        end

        return nil
    end

    function TBH.Server.Request(ply, input, includeReqs, titleHint)
        local allowed, reason = CanHotload(ply)
        if not allowed then
            StatusTo(ply, "Permission denied: " .. tostring(reason), 2)
            return
        end

        local wsid = TBH.ExtractWSID(input)
        if not wsid then
            StatusTo(ply, "That doesn't look like a workshop id or url", 2)
            return
        end

        -- per-player cooldown
        if IsValid(ply) then
            local sid = ply:SteamID()
            local cooldownUntil = TBH.Server.PlayerCooldown[sid] or 0

            if CurTime() < cooldownUntil then
                StatusTo(ply, "Cooling down - wait " .. math.ceil(cooldownUntil - CurTime()) .. "s", 3)
                return
            end

            TBH.Server.PlayerCooldown[sid] = CurTime() + TBH.CVarCooldown:GetInt()
        end

        local known = AlreadyKnown(wsid)
        if known then
            StatusTo(ply, "Skipping " .. wsid .. ": " .. known, 3)
            return
        end

        local failUntil = TBH.Server.FailedUntil[wsid] or 0
        if CurTime() < failUntil then
            StatusTo(ply, "That addon recently failed - retry in " .. math.ceil(failUntil - CurTime()) .. "s", 3)
            return
        end

        local title = (isstring(titleHint) and titleHint ~= "") and titleHint or nil

        ----------------------------------------------------------------
        -- No server-side download available?
        ----------------------------------------------------------------
        if not TBH.ServerCanUGC then
            if game.IsDedicated() then
                StatusTo(ply, "The gmsv_workshop module is not installed - dedicated servers need it to download addons!", 2)
                TBH.LogError("Hotload requested but gmsv_workshop is missing.")
                TBH.LogError("Install it from https://github.com/nooshstuff/gmsv_workshop/releases (v3.0.4+)")
                TBH.LogError("64-bit server: gmsv_workshop_win64.dll or gmsv_workshop_linux64.dll -> garrysmod/lua/bin/")
                return
            end

            -- listen server fallback: host client downloads for us
            local host = FindHostPlayer()
            if not IsValid(host) then
                StatusTo(ply, "Host player not found yet - try again in a few seconds", 3)
                return
            end

            if includeReqs and TBH.CVarRequirements:GetBool() then
                StatusTo(ply, "Note: requirement chains need the gmsv_workshop module - loading the main addon only", 3)
            end

            if TBH.Server.HostPending[wsid] then
                StatusTo(ply, "Already routing that one through the host player", 3)
                return
            end

            TBH.Server.HostPending[wsid] = { requester = ply }
            StatusTo(ply, "Routing download through the host player (no gmsv_workshop module)...", 0)

            timer.Create("TBH.HostWait." .. wsid, 90, 1, function()
                if TBH.Server.HostPending[wsid] then
                    TBH.Server.HostPending[wsid] = nil
                    TBH.Server.FailedUntil[wsid] = CurTime() + 60
                    StatusTo(ply, "Host download of " .. wsid .. " timed out", 2)
                end
            end)

            TBH.Net:Start("hostdl")
            net.WriteString(wsid)
            net.WriteString(title or "")
            net.Send(host)

            return
        end

        ----------------------------------------------------------------
        -- Requirements chain
        ----------------------------------------------------------------
        if includeReqs and TBH.CVarRequirements:GetBool() then
            StatusTo(ply, "Checking required addons for \"" .. (title or wsid) .. "\"...", 0)

            local fired = false

            local function Proceed(reqIds)
                if fired then return end
                fired = true
                timer.Remove("TBH.ReqTimeout." .. wsid)

                local toLoad = {}
                for i = 1, #reqIds do
                    local id = reqIds[i]
                    if not AlreadyKnown(id) then
                        toLoad[#toLoad + 1] = id
                    end
                end

                if #toLoad > 0 then
                    StatusTo(ply, "Hotloading " .. #toLoad .. " required addon(s) first", 0)
                    for i = 1, #toLoad do
                        Enqueue(toLoad[i], nil, ply)
                    end
                end

                Enqueue(wsid, title, ply)
                ProcessQueue()
            end

            timer.Create("TBH.ReqTimeout." .. wsid, 20, 1, function()
                Proceed({})
            end)

            TBH.GetRequiredAddons(wsid, Proceed)
            return
        end

        Enqueue(wsid, title, ply)
        ProcessQueue()
    end

    --------------------------------------------------------------------
    -- Net receivers
    --------------------------------------------------------------------

    TBH.Net:Receive("req", function(len, ply)
        local wsid = net.ReadString()
        local includeReqs = net.ReadBool()
        local titleHint = net.ReadString()

        TBH.Server.Request(ply, wsid, includeReqs, titleHint)
    end)

    TBH.Net:Receive("result", function(len, ply)
        local wsid = net.ReadString()
        local ok = net.ReadBool()
        local errCount = net.ReadUInt(16)
        local errSummary = net.ReadString()

        local track = TBH.Server.Sync[wsid]
        if not track then return end

        if ok then
            track.ok = track.ok + 1
        else
            track.failed = track.failed + 1
            track.failedNames[#track.failedNames + 1] = (IsValid(ply) and ply:Nick() or "?") .. ": " .. errSummary
        end
    end)

    TBH.Net:Receive("resync", function(len, ply)
        if not IsValid(ply) then return end
        TBH.Server.SendSyncList(ply)
    end)

    --------------------------------------------------------------------
    -- Listen-server host fallback receivers
    --------------------------------------------------------------------

    TBH.Net:Receive("hostchunk", function(len, ply)
        if not IsValid(ply) or not ply:IsListenServerHost() then return end

        local wsid = net.ReadString()
        local total = net.ReadUInt(8)
        local idx = net.ReadUInt(8)
        local dlen = net.ReadUInt(16)
        local data = net.ReadData(dlen)

        if total < 1 or total > 255 or idx < 1 or idx > total then return end

        local entry = TBH.Server.HostBundles[wsid]

        if not entry then
            entry = { total = total, chunks = {}, got = 0, title = "" }
            TBH.Server.HostBundles[wsid] = entry

            timer.Create("TBH.HostBundle." .. wsid, 60, 1, function()
                TBH.Server.HostBundles[wsid] = nil
            end)
        end

        if not entry.chunks[idx] then
            entry.chunks[idx] = data
            entry.got = entry.got + 1
        end
    end)

    TBH.Net:Receive("hostdone", function(len, ply)
        if not IsValid(ply) or not ply:IsListenServerHost() then return end

        local wsid = net.ReadString()
        local title = net.ReadString()
        local entry = TBH.Server.HostBundles[wsid]
        local pending = TBH.Server.HostPending[wsid]

        timer.Remove("TBH.HostBundle." .. wsid)
        timer.Remove("TBH.HostWait." .. wsid)
        TBH.Server.HostBundles[wsid] = nil
        TBH.Server.HostPending[wsid] = nil

        if not entry or entry.got < entry.total then
            TBH.Server.FailedUntil[wsid] = CurTime() + 60
            if pending then
                StatusTo(pending.requester, "Host transfer for " .. wsid .. " was incomplete", 2)
            end
            return
        end

        local buffer = {}
        for i = 1, entry.total do
            buffer[#buffer + 1] = entry.chunks[i]
        end

        local json = util.Decompress(table.concat(buffer))
        local files = json and util.JSONToTable(json)

        if not istable(files) then
            TBH.Server.FailedUntil[wsid] = CurTime() + 60
            if pending then
                StatusTo(pending.requester, "Host transfer for " .. wsid .. " was corrupt", 2)
            end
            return
        end

        local maxFiles = TBH.CVarMaxFiles:GetInt()
        if #files > maxFiles then
            TBH.Server.FailedUntil[wsid] = CurTime() + 60
            if pending then
                StatusTo(pending.requester, "Addon has " .. #files .. " files (limit: " .. maxFiles .. ")", 2)
            end
            return
        end

        if not isstring(title) or title == "" then title = wsid end

        local requester = pending and pending.requester or nil

        local okFinalize, errFinalize = pcall(FinalizeMount, wsid, title, files, requester, true)
        if not okFinalize then
            TBH.LogError("FinalizeMount crashed: " .. tostring(errFinalize))
            if requester then
                StatusTo(requester, "Hotload of \"" .. title .. "\" crashed during initialization (see server console)", 2)
            end
        end
    end)

    TBH.Net:Receive("hostfail", function(len, ply)
        if not IsValid(ply) or not ply:IsListenServerHost() then return end

        local wsid = net.ReadString()
        local pending = TBH.Server.HostPending[wsid]

        timer.Remove("TBH.HostWait." .. wsid)
        TBH.Server.HostPending[wsid] = nil
        TBH.Server.FailedUntil[wsid] = CurTime() + 60

        if pending then
            StatusTo(pending.requester, "Host download of " .. wsid .. " failed", 2)
        end
    end)

    --------------------------------------------------------------------
    -- Late-join sync
    --------------------------------------------------------------------

    function TBH.Server.SendSyncList(ply)
        if not IsValid(ply) then return end

        -- NOTE: sent even when empty - the client prunes stale session
        -- entries against this list, so a restarted server = clean lists
        local entries = {}
        for wsid, data in pairs(TBH.Server.Mounted) do
            entries[#entries + 1] = { wsid = wsid, title = data.title or wsid, maps = data.maps }
        end

        if #entries > 400 then
            for i = #entries, 401, -1 do
                entries[i] = nil
            end
        end

        TBH.Net:Start("sync")
        net.WriteUInt(#entries, 16)

        for i = 1, #entries do
            net.WriteString(entries[i].wsid)
            net.WriteString(entries[i].title)
            WriteMaps(entries[i].maps)
        end

        net.Send(ply)
    end

    hook.Add("PlayerInitialSpawn", "TBH.LateSync", function(ply)
        if not TBH.CVarLateSync:GetBool() then return end

        timer.Simple(4, function()
            if not IsValid(ply) then return end
            TBH.Server.SendSyncList(ply)
        end)
    end)

    -- dump failed sync details for admins
    concommand.Add("tbh_syncstatus", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        for wsid, track in pairs(TBH.Server.Sync) do
            if track.failed > 0 then
                TBH.Msg(wsid .. ": " .. track.ok .. " ok, " .. track.failed .. " failed")
                for i = 1, #track.failedNames do
                    TBH.Msg("    " .. track.failedNames[i], TBH.Colors.textdim)
                end
            end
        end
    end)

    --------------------------------------------------------------------
    -- "Load Map": change the level to a map inside a hotloaded addon
    --
    -- Every player (and late joiners) mount the addon with the .bsp in it,
    -- so they can all join the new map. Admin permission required.
    --------------------------------------------------------------------

    TBH.Server.CanHotload = CanHotload

    local mapChangeArmed = false

    local function LoadMap(ply, mapname)
        if mapChangeArmed then
            StatusTo(ply, "A map change is already in progress...", 3)
            return
        end

        if not isstring(mapname) or mapname == "" then
            StatusTo(ply, "No map name given", 2)
            return
        end

        -- sanitize: map names are word chars, dashes, underscores and dots
        mapname = string.match(mapname, "^([%w_%-%.]+)$")

        if not mapname then
            StatusTo(ply, "That is not a valid map name", 2)
            return
        end

        -- the map must exist: either in a hotloaded addon or on the server
        local found = file.Exists("maps/" .. mapname .. ".bsp", "GAME")

        if not found then
            StatusTo(ply, "Map \"" .. mapname .. "\" does not exist on the server (hotload the map addon first!)", 2)
            return
        end

        mapChangeArmed = true

        ChatBroadcast("Changing level to \"" .. mapname .. "\" in 5 seconds - everyone has the map!", 1)

        -- the long hint (10s on screen): big maps = long download, tell people to WAIT
        ChatBroadcast("If you get stuck on \"Establishing connection to server\" after the change, the map is DOWNLOADING - big maps can take a few minutes. Just wait, do not disconnect!", 3, 10)

        TBH.Msg("Changing level to " .. mapname .. " (requested by " .. (IsValid(ply) and ply:Nick() or "console") .. ")")

        timer.Simple(5, function()
            game.ConsoleCommand("changelevel " .. mapname .. "\n")

            -- safety: re-allow after 30s if the changelevel didn't happen
            timer.Simple(30, function()
                mapChangeArmed = false
            end)
        end)
    end

    TBH.Net:Receive("loadmap", function(len, ply)
        if not IsValid(ply) then return end

        local allowed, reason = CanHotload(ply)
        if not allowed then
            StatusTo(ply, "Permission denied: " .. tostring(reason), 2)
            return
        end

        LoadMap(ply, net.ReadString())
    end)

    concommand.Add("tbh_loadmap", function(ply, cmd, args)
        local allowed = not IsValid(ply)

        if not allowed then
            allowed = select(1, CanHotload(ply))
        end

        if not allowed then
            StatusTo(ply, "Permission denied: map switching follows the hotload permission (tbh_permission)", 2)
            return
        end

        LoadMap(ply, args and args[1] or "")
    end)

    --------------------------------------------------------------------
    -- Soft unload (tbh_unload <wsid> [kill])
    --
    -- Removes everything the addon's Lua is doing: hooks, timers, spawnmenu
    -- entries, scripted classes (best effort) and optionally every entity
    -- the addon spawned. The addon's FILES (models/materials/sounds) stay
    -- mounted - GMod has no unmount API (see README, "Unloading" section).
    --------------------------------------------------------------------

    local function UnloadAddon(wsid, ply, removeEntities)
        local entry = TBH.Server.Mounted[wsid]

        if not entry then
            StatusTo(ply, "Nothing hotloaded under id " .. tostring(wsid), 2)
            return
        end

        if entry.unloaded then
            StatusTo(ply, "\"" .. (entry.title or wsid) .. "\" is already unloaded", 3)
            return
        end

        local bundle = entry.bundle

        if istable(bundle) and isfunction(bundle.Unload) then
            local ok, err = pcall(bundle.Unload, bundle, removeEntities)
            if not ok then
                TBH.LogError("Unload crashed for " .. wsid .. ": " .. tostring(err))
            end
        end

        entry.unloaded = true

        -- tell every client to unload their copy too
        TBH.Net:Start("unload")
        net.WriteString(wsid)
        net.WriteBool(removeEntities or false)
        net.Broadcast()

        ChatBroadcast("Unloaded \"" .. (entry.title or wsid) .. "\" (Lua removed; files stay mounted - see README)", 3)
        StatusTo(ply, "Unloaded \"" .. (entry.title or wsid) .. "\" - hooks/timers/entities gone, content stays mounted", 1)
        TBH.Msg("Soft-unloaded " .. wsid .. " (" .. (entry.title or "?") .. ")" .. (removeEntities and " + removed entities" or ""))
    end

    concommand.Add("tbh_unload", function(ply, cmd, args)
        local allowed = not IsValid(ply)

        if not allowed then
            allowed = select(1, CanHotload(ply))
        end

        if not allowed then
            StatusTo(ply, "Permission denied: unloading follows the hotload permission (tbh_permission)", 2)
            return
        end

        local wsid = TBH.ExtractWSID(args and args[1] or "")

        if not wsid then
            TBH.Msg("Usage: tbh_unload <workshop id or url> [1 = also remove spawned entities]")
            if IsValid(ply) then
                StatusTo(ply, "Usage: tbh_unload <id or url> [1 = remove entities]", 3)
            end
            return
        end

        UnloadAddon(wsid, ply, tobool(args[2]))
    end)

    -- client-initiated unload (right-click menu in the spawnmenu)
    TBH.Net:Receive("unloadreq", function(len, ply)
        if not IsValid(ply) then return end

        local allowed, reason = CanHotload(ply)
        if not allowed then
            StatusTo(ply, "Permission denied: " .. tostring(reason), 2)
            return
        end

        UnloadAddon(net.ReadString(), ply, net.ReadBool())
    end)

    --------------------------------------------------------------------
    -- Session safeguard
    --
    -- Hotloaded addons ONLY live in memory: nothing is written to disk and
    -- a restart always starts brand new. This safeguard additionally wipes
    -- the session registry when the last player leaves (host included), so
    -- the next session on a long-running server starts completely clean.
    -- Nothing is permanently deleted from Steam's own download cache, but
    -- no hotloaded addon "exists" anymore until someone hotloads it again.
    --------------------------------------------------------------------

    local function WipeSession()
        TBH.Server.Mounted = {}
        TBH.Server.Queue = {}
        TBH.Server.Sync = {}
        TBH.Server.FailedUntil = {}
        TBH.Server.PlayerCooldown = {}
        TBH.Server.HostBundles = {}
        TBH.Server.HostPending = {}
        TBH.Server.Current = nil
    end

    TBH.Server.WipeSession = WipeSession

    hook.Add("PlayerDisconnected", "TBH.CleanupOnEmpty", function(ply)
        if not TBH.CVarCleanupEmpty:GetBool() then return end

        -- give the engine a moment to update the player list
        timer.Simple(2, function()
            if #player.GetAll() == 0 then
                WipeSession()
                TBH.Msg("Server is empty - hotload session wiped. The next session starts completely fresh.")
            end
        end)
    end)

    -- full restart = always brand new; wipe on shutdown too so nothing can
    -- ever carry over (belt and suspenders - it is all in-memory anyway)
    hook.Add("ShutDown", "TBH.Cleanup", function()
        WipeSession()
    end)

    concommand.Add("tbh_wipe", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        WipeSession()
        TBH.Msg("Hotload session wiped by " .. (IsValid(ply) and ply:Nick() or "console") .. " - every hotloaded addon is gone until re-hotloaded.")
    end)
end


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  CLIENT PIPELINE
--
--  Receives "mount"/"sync" from the server, downloads each addon with the
--  native client steamworks.DownloadUGC, mounts it, and initializes all
--  client-side Lua (autorun/client, cl_init, PANELs, effects, stools...).
--
--  Listen-server hosts can additionally download on the server's behalf
--  when the gmsv_workshop module is not installed.
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

if CLIENT then
    TBH.Client = {
        Queue = {},
        Busy = false,
        Mounted = {},   -- [wsid] = { title, files, time, errors, maps, bundle, unloaded }
        Known = {},     -- [wsid] = { title, maps }  (everything the server told us about)
        HostLoading = nil,
        AutoLoadMap = {},  -- [wsid] = true when the browser's LOAD MAP button was used
        Meta = {},          -- [wsid] = { title, author, imageFile, fetched, failed }
    }

    ------------------------------------------------------------------------------
    -- Session reset
    --
    -- The client Lua state SURVIVES map changes and server restarts (that is
    -- exactly why hotloading works at all). Without this, the session list
    -- would keep showing addons from a previous server session until you
    -- restart your whole game. GM:InitPostEntity fires every time you spawn
    -- into a map, so we wipe the session here - a fresh map/server = a
    -- brand new session list, exactly like a full restart.
    ------------------------------------------------------------------------------

    hook.Add("InitPostEntity", "TBH.SessionReset", function()
        TBH.Client.Known = {}
        TBH.Client.Queue = {}
        TBH.Client.Mounted = {}
        TBH.Client.AutoLoadMap = {}
        TBH.Client.Busy = false
        TBH.Client.HostLoading = nil

        hook.Run("TBH.ClientListChanged")
    end)

    ------------------------------------------------------------------------------
    -- Workshop metadata + preview thumbnails
    --
    -- Fetches the addon's workshop page once, pulls out the title, author and
    -- preview image URL, downloads the image into data/hotloader_icons/ and
    -- re-renders the session list. Fully cached on disk afterwards.
    --
    -- NOTE the material path: Material() resolves paths relative to
    -- materials/, so a file in data/ must be loaded as "../data/...".
    ------------------------------------------------------------------------------

    local metaFetching = {}

    local function TryMaterial(path)
        local ok, mat = pcall(Material, path, "smooth")
        if ok and mat and not mat:IsError() then
            return mat
        end
        return nil
    end

    function TBH.GetAddonImage(wsid)
        local meta = TBH.Client.Meta[wsid]

        if meta and meta.imageFile then
            return TryMaterial("../data/hotloader_icons/" .. meta.imageFile)
        end

        return nil
    end

    function TBH.FetchAddonMeta(wsid)
        if not TBH.IsValidWSID(wsid) then return end

        local meta = TBH.Client.Meta[wsid]

        -- already done (or failed permanently)?
        if meta and (meta.fetched or meta.failed) then return end
        if metaFetching[wsid] then return end

        metaFetching[wsid] = true
        TBH.Client.Meta[wsid] = meta or {}

        http.Fetch(TBH.WorkshopURL(wsid), function(body, size, headers, code)
            metaFetching[wsid] = nil

            if not isstring(body) or body == "" or (code and (code < 200 or code > 299)) then
                TBH.Client.Meta[wsid].failed = true
                return
            end

            local meta2 = TBH.Client.Meta[wsid]
            meta2.fetched = true

            -- title / author
            local pageTitle = string_match(body, '<div class="workshopItemTitle">([^<]-)</div>')
            local author = string_match(body, '<div class="friendBlockContent">%s*([^<\n]+)')

            if isstring(pageTitle) and pageTitle ~= "" then
                meta2.title = string_gsub(pageTitle, "^%s+", "")
            end

            if isstring(author) and author ~= "" then
                meta2.author = string_gsub(author, "^%s+", "")
            end

            -- preview image URL (several layouts Steam uses, best first:
            -- og:image is a tidy 512x512 thumb on current workshop pages)
            local imgURL = string_match(body, 'property="og:image"[^>]-content="([^"]+)"')
                or string_match(body, 'og:image"%s+content="([^"]+)"')
                or string_match(body, 'id="previewImage"[^>]-src="([^"]+)"')
                or string_match(body, 'src="([^"]+)"[^>]-id="previewImage"')
                or string_match(body, 'https://images%.steamusercontent%.com/ugc/[%w%/]+')
                or string_match(body, 'https://steamuserimages%-a%.akamaihd%.net/ugc/[%w%/]+')

            if not isstring(imgURL) or not string_match(imgURL, "^https?://") then
                hook.Run("TBH.ClientListChanged")
                return
            end

            -- HTML entity unescape (&amp; -> &) - steam's og:image URLs are
            -- full of query params with escaped ampersands
            imgURL = string_gsub(imgURL, "&amp;", "&")

            local ext = string_match(imgURL, "%.(%w-)%s*$")

            -- already cached on disk?
            for _, tryExt in ipairs({ ext, "jpg", "png" }) do
                if tryExt == "jpg" or tryExt == "png" then
                    if file.Exists("hotloader_icons/" .. wsid .. "." .. tryExt, "DATA") then
                        meta2.imageFile = wsid .. "." .. tryExt
                        hook.Run("TBH.ClientListChanged")
                        return
                    end
                end
            end

            http.Fetch(imgURL, function(imgBody, imgSize, imgHeaders, imgCode)
                if not isstring(imgBody) or imgSize == 0 or #imgBody < 128 then return end
                if imgCode and (imgCode < 200 or imgCode > 299) then return end

                -- pick the extension from the actual magic bytes (Material()
                -- needs .png or .jpg - the real format may differ, that's ok)
                local realExt = "jpg"

                if string_sub(imgBody, 1, 3) == string.char(0x89) .. "PN" or
                   string_sub(imgBody, 1, 8) == string.char(0x89) .. "PNG\r\n" .. string.char(0x1A) .. string.char(0x0A) then
                    realExt = "png"
                elseif ext == "png" and string_sub(imgBody, 1, 3) ~= string.char(0xFF, 0xD8, 0xFF) then
                    realExt = "png"
                end

                local outFile = wsid .. "." .. realExt

                file.CreateDir("hotloader_icons")
                file.Write("hotloader_icons/" .. outFile, imgBody)

                -- verify the material actually loads before using it
                local mat = TryMaterial("../data/hotloader_icons/" .. outFile)

                if mat then
                    meta2.imageFile = outFile
                else
                    -- corrupt image - drop it so we don't retry forever
                    file.Delete("hotloader_icons/" .. outFile)
                    meta2.imageFailed = true
                end

                hook.Run("TBH.ClientListChanged")
            end, function()
                meta2.imageFailed = true
            end)

        end, function()
            metaFetching[wsid] = nil
            TBH.Client.Meta[wsid].failed = true
        end)
    end

    ------------------------------------------------------------------------------
    -- Auto-hotload on Steam subscribe / addon enable
    --
    -- Snapshots the local addon list at boot. When the game reports content
    -- changes (a new subscription finishing its download, or the player
    -- enabling a previously disabled addon), the new id is sent to the server
    -- as a hotload request. The server still applies its own permission
    -- check, cooldown and queue - this only fires the request.
    ------------------------------------------------------------------------------

    TBH.SubWatch = { All = {}, Unmounted = {}, Downloading = {} }

    do
        local addons = engine.GetAddons()

        for i = 1, #addons do
            local addon = addons[i]
            local id = addon.wsid

            if id and id ~= "" then
                TBH.SubWatch.All[id] = true

                if not addon.mounted then
                    TBH.SubWatch.Unmounted[id] = true
                end
            end
        end
    end

    -- mark a wsid as known so our own hotload mounts don't re-trigger the watch
    function TBH.MarkWatched(wsid)
        TBH.SubWatch.All[wsid] = true
        TBH.SubWatch.Unmounted[wsid] = nil
    end

    hook.Add("GameContentChanged", "TBH.AutoSubscribe", function()
        local wantSubs = TBH.CVarAutoSubscribe and TBH.CVarAutoSubscribe:GetBool()
        local wantEnable = TBH.CVarEnableAddons and TBH.CVarEnableAddons:GetBool()

        if not wantSubs and not wantEnable then return end

        -- give Steam a moment to update the addon list
        timer.Simple(1, function()
            local wantSubsNow = TBH.CVarAutoSubscribe and TBH.CVarAutoSubscribe:GetBool()
            local wantEnableNow = TBH.CVarEnableAddons and TBH.CVarEnableAddons:GetBool()

            if not wantSubsNow and not wantEnableNow then return end

            local addons = engine.GetAddons()
            local fresh = {}

            for i = 1, #addons do
                local addon = addons[i]
                local id = addon.wsid

                if id and id ~= "" and TBH.IsValidWSID(id) then
                    local mounted = addon.mounted and true or false
                    local known = TBH.SubWatch.All[id]
                    local knownUnmounted = TBH.SubWatch.Unmounted[id]
                    local wasDownloading = TBH.SubWatch.Downloading[id]

                    if wasDownloading and mounted then
                        -- a subscription we saw mid-download just finished
                        TBH.SubWatch.Downloading[id] = nil
                        if wantSubsNow then fresh[#fresh + 1] = id end
                    elseif not known then
                        -- first time we ever see this id
                        if mounted then
                            if knownUnmounted then
                                -- was disabled before we tracked it -> enable
                                if wantEnableNow then fresh[#fresh + 1] = id end
                            else
                                -- arrived fully mounted -> new subscription
                                if wantSubsNow then fresh[#fresh + 1] = id end
                            end
                        else
                            -- brand new, still downloading - remember it so the
                            -- completion event fires as a SUBSCRIBE
                            TBH.SubWatch.Downloading[id] = true
                        end
                    elseif knownUnmounted and mounted then
                        -- previously disabled addon got enabled
                        if wantEnableNow then fresh[#fresh + 1] = id end
                    end

                    -- keep the tracking tables in sync (also marks seen-but-
                    -- not-fired addons so they never re-fire later)
                    TBH.SubWatch.All[id] = true

                    if mounted then
                        TBH.SubWatch.Unmounted[id] = nil
                    else
                        TBH.SubWatch.Unmounted[id] = true
                    end
                end
            end

            -- cap the burst so nobody spams 50 subscriptions at once
            local count = math.min(#fresh, 5)

            for i = 1, count do
                local wsid = fresh[i]

                TBH.NotifyLocally("New addon detected (subscribe/enable) - requesting hotload...", 0)
                TBH.RequestHotload(wsid, "")
            end
        end)
    end)

    --------------------------------------------------------------------
    -- Result reporting
    --------------------------------------------------------------------

    local function ReportResult(wsid, ok, errCount, errSummary)
        TBH.Net:Start("result")
        net.WriteString(wsid)
        net.WriteBool(ok)
        net.WriteUInt(math.Clamp(errCount or 0, 0, 65535), 16)
        net.WriteString(string_sub(tostring(errSummary or ""), 1, 180))
        net.SendToServer()
    end
    TBH.ClientReportResult = ReportResult

    --------------------------------------------------------------------
    -- Download queue
    --------------------------------------------------------------------

    function TBH.ClientEnqueue(wsid, title)
        for i = 1, #TBH.Client.Queue do
            if TBH.Client.Queue[i].wsid == wsid then return end
        end

        if TBH.Client.Mounted[wsid] then return end

        -- prevent our own mounts from re-triggering the subscribe watcher
        TBH.MarkWatched(wsid)

        TBH.Client.Queue[#TBH.Client.Queue + 1] = { wsid = wsid, title = title }
        TBH.ProcessClientQueue()
    end

    function TBH.ProcessClientQueue()
        if TBH.Client.Busy then return end

        local entry = table.remove(TBH.Client.Queue, 1)
        if not entry then
            hook.Run("TBH.ClientListChanged")
            return
        end

        TBH.Client.Busy = true

        local wsid = entry.wsid
        local title = entry.title or wsid
        local finished = false

        local function Finish(ok, errCount, errSummary)
            if finished then return end
            finished = true

            timer.Remove("TBH.ClientDL." .. wsid)
            TBH.Client.Busy = false

            if ok then
                TBH.NotifyLocally("\"" .. title .. "\" hotloaded!", 1)
            else
                TBH.NotifyLocally("Failed to sync \"" .. title .. "\": " .. tostring(errSummary or "unknown error"), 2)
            end

            hook.Run("TBH.ClientListChanged")
            timer.Simple(0.5, TBH.ProcessClientQueue)
        end

        TBH.NotifyLocally("Downloading \"" .. title .. "\"...", 0)

        timer.Create("TBH.ClientDL." .. wsid, 240, 1, function()
            Finish(false, 1, "download timed out")
        end)

        steamworks.DownloadUGC(wsid, function(path, gmaFile)
            if finished then return end

            if not path or not gmaFile then
                ReportResult(wsid, false, 1, "download failed")
                return Finish(false, 1, "download failed (hidden/removed addon or Steam offline?)")
            end

            local ok, files = game.MountGMA(path)

            if not ok or not istable(files) then
                ReportResult(wsid, false, 1, "mount failed")
                return Finish(false, 1, "could not mount the addon")
            end

            local cleanFiles, seen = {}, {}
            for _, f in pairs(files) do
                if not seen[f] then
                    seen[f] = true
                    cleanFiles[#cleanFiles + 1] = f
                end
            end

            local gmaTitle = TBH.GetGMATitle(path)
            if gmaTitle and #gmaTitle > 0 then
                title = gmaTitle
            end

            -- small delay so the filesystem catch-up + UI don't fight each other
            timer.Simple(0.3, function()
                if finished then return end

                local okBundle, bundle = pcall(function()
                    local b = TBH.Bundle:Create(cleanFiles, title)
                    b:Initialize()
                    return b
                end)

                bundle = istable(bundle) and bundle or nil

                if not okBundle or not bundle then
                    TBH.Client.Mounted[wsid] = {
                        title = title,
                        files = #cleanFiles,
                        time = os.time(),
                        errors = 1,
                    }
                    ReportResult(wsid, false, 1, "client initialization crashed")
                    return Finish(false, 1, "client initialization crashed")
                end

                TBH.Client.Mounted[wsid] = {
                    title = title,
                    files = #cleanFiles,
                    time = os.time(),
                    errors = #bundle.Errors,
                    maps = TBH.ExtractMaps(cleanFiles),
                    bundle = bundle,
                    unloaded = false,
                }

                local okResult = (#bundle.Errors == 0)
                ReportResult(wsid, okResult, #bundle.Errors, bundle.Errors[1])
                Finish(okResult, #bundle.Errors, bundle.Errors[1])
            end)
        end)
    end

    --------------------------------------------------------------------
    -- Server messages
    --------------------------------------------------------------------

    local function ReadMaps()
        local count = net.ReadUInt(8)
        local maps = {}

        for i = 1, count do
            maps[#maps + 1] = net.ReadString()
        end

        return maps
    end

    TBH.Net:Receive("mount", function()
        local wsid = net.ReadString()
        local title = net.ReadString()
        local maps = ReadMaps()

        TBH.Client.Known[wsid] = { title = title, time = os.time(), maps = maps }
        TBH.FetchAddonMeta(wsid)
        hook.Run("TBH.ClientListChanged")

        -- the browser's LOAD MAP button was used on this addon: once the
        -- server has it mounted (that's what this message means), switch!
        if TBH.Client.AutoLoadMap[wsid] then
            TBH.Client.AutoLoadMap[wsid] = nil

            timer.Simple(3, function()
                if istable(maps) and #maps == 1 then
                    TBH.NotifyLocally("Map addon is on the server - switching to \"" .. maps[1] .. "\"... (players still syncing download it from the server)", 0)
                    TBH.RequestLoadMap(maps[1])
                elseif istable(maps) and #maps > 1 then
                    TBH.NotifyLocally("That addon contains " .. #maps .. " maps - right-click it in the Hotloader tab to pick one", 3)
                else
                    TBH.NotifyLocally("That addon turned out to contain no maps!", 2)
                end
            end)
        end

        if TBH.Client.Mounted[wsid] then
            ReportResult(wsid, true, 0, "already mounted")
            return
        end

        TBH.ClientEnqueue(wsid, title)
    end)

    TBH.Net:Receive("sync", function()
        local count = net.ReadUInt(16)
        local pending = 0

        local serverList = {}

        for i = 1, count do
            local wsid = net.ReadString()
            local title = net.ReadString()
            local maps = ReadMaps()

            serverList[wsid] = true
            TBH.Client.Known[wsid] = { title = title, time = os.time(), maps = maps }
            TBH.FetchAddonMeta(wsid)

            if not TBH.Client.Mounted[wsid] then
                TBH.ClientEnqueue(wsid, title)
                pending = pending + 1
            end
        end

        -- prune stale entries: things we requested/queued earlier that the
        -- server now says it doesn't have (denied, failed, or a restarted
        -- server). Never touch entries that are mounted or still queued.
        for wsid, entry in pairs(TBH.Client.Known) do
            if not serverList[wsid] and not TBH.Client.Mounted[wsid] then
                local queued = false

                for i = 1, #TBH.Client.Queue do
                    if TBH.Client.Queue[i].wsid == wsid then queued = true break end
                end

                if not queued then
                    TBH.Client.Known[wsid] = nil
                end
            end
        end

        if pending > 0 then
            TBH.NotifyLocally("Syncing " .. pending .. " hotloaded addon(s) - sit tight...", 0)
        end

        hook.Run("TBH.ClientListChanged")
    end)

    TBH.Net:Receive("status", function()
        local level = net.ReadUInt(8)
        local msg = net.ReadString()
        TBH.NotifyLocally(msg, level)
    end)

    -- server unloaded an addon: unload our client-side copy too
    TBH.Net:Receive("unload", function()
        local wsid = net.ReadString()
        local removeEntities = net.ReadBool()

        local entry = TBH.Client.Mounted[wsid]

        if istable(entry) then
            local bundle = entry.bundle

            if istable(bundle) and isfunction(bundle.Unload) then
                local ok, err = pcall(bundle.Unload, bundle, removeEntities)
                if not ok then
                    MsgC(TBH.Colors.error, "[Hotloader] unload crashed: " .. tostring(err) .. "\n")
                end
            end

            entry.unloaded = true
        end

        if istable(TBH.Client.Known[wsid]) then
            TBH.Client.Known[wsid].unloaded = true
        end

        hook.Run("TBH.ClientListChanged")
    end)

    TBH.Net:Receive("chatmsg", function()
        local level = net.ReadUInt(8)
        local duration = net.ReadUInt(8)
        local msg = net.ReadString()

        local color = TBH.Colors.text
        if level == 1 then color = Color(190, 240, 160) end
        if level == 3 then color = TBH.Colors.warn end

        chat.AddText(TBH.Colors.tag, "[Hotloader] ", color, msg)

        -- long announcements (like the map-change wait hint) also pop up as
        -- an on-screen notification so nobody misses them
        if isnumber(duration) and duration > 0 then
            notification.AddLegacy("[Hotloader] " .. string_sub(msg, 1, 140), NOTIFY_GENERIC, math.Clamp(duration, 1, 30))
        end
    end)

    --------------------------------------------------------------------
    -- Listen host fallback: download on the server's behalf
    --------------------------------------------------------------------

    TBH.Net:Receive("hostdl", function()
        local wsid = net.ReadString()
        local titleHint = net.ReadString()

        -- prevent our own mounts from re-triggering the subscribe watcher
        TBH.MarkWatched(wsid)

        if TBH.Client.Mounted[wsid] then return end
        if TBH.Client.HostLoading == wsid then return end

        TBH.Client.HostLoading = wsid

        local function HostFail(reason)
            if TBH.Client.HostLoading ~= wsid then return end
            TBH.Client.HostLoading = nil

            TBH.NotifyLocally("Host download of " .. wsid .. " failed: " .. tostring(reason), 2)

            TBH.Net:Start("hostfail")
            net.WriteString(wsid)
            net.SendToServer()
        end

        steamworks.DownloadUGC(wsid, function(path, gmaFile)
            if TBH.Client.HostLoading ~= wsid then return end

            if not path or not gmaFile then
                return HostFail("download failed")
            end

            local ok, files = game.MountGMA(path)

            if not ok or not istable(files) then
                return HostFail("mount failed")
            end

            local cleanFiles, seen = {}, {}
            for _, f in pairs(files) do
                if not seen[f] then
                    seen[f] = true
                    cleanFiles[#cleanFiles + 1] = f
                end
            end

            local title = TBH.GetGMATitle(path) or titleHint
            if not isstring(title) or title == "" then title = wsid end

            -- ship the file list to the server in <=60KB chunks
            local compressed = util.Compress(util.TableToJSON(cleanFiles))

            if not compressed then
                return HostFail("could not package the file list")
            end

            local total = math.ceil(#compressed / 60000)

            if total < 1 or total > 255 then
                return HostFail("addon file list too big")
            end

            for i = 1, total do
                local chunk = string_sub(compressed, (i - 1) * 60000 + 1, i * 60000)

                TBH.Net:Start("hostchunk")
                net.WriteString(wsid)
                net.WriteUInt(total, 8)
                net.WriteUInt(i, 8)
                net.WriteUInt(#chunk, 16)
                net.WriteData(chunk, #chunk)
                net.SendToServer()
            end

            TBH.Net:Start("hostdone")
            net.WriteString(wsid)
            net.WriteString(title)
            net.SendToServer()

            TBH.Client.HostLoading = nil

            -- give the server a moment to initialize first, then run the
            -- client-side files (mirrors boot order: server before client)
            timer.Simple(1.5, function()
                local okBundle, bundle = pcall(function()
                    local b = TBH.Bundle:Create(cleanFiles, title)
                    b:Initialize()
                    return b
                end)

                bundle = istable(bundle) and bundle or nil
                local errCount = (okBundle and bundle) and #bundle.Errors or 1

                TBH.Client.Mounted[wsid] = {
                    title = title,
                    files = #cleanFiles,
                    time = os.time(),
                    errors = errCount,
                    maps = TBH.ExtractMaps(cleanFiles),
                    bundle = istable(bundle) and bundle or nil,
                    unloaded = false,
                }

                if not okBundle or not bundle then
                    TBH.NotifyLocally("Client init of \"" .. title .. "\" crashed (see console)", 2)
                else
                    TBH.NotifyLocally("\"" .. title .. "\" hotloaded!", 1)
                end

                hook.Run("TBH.ClientListChanged")
            end)
        end)
    end)

    --------------------------------------------------------------------
    -- Client-side request helpers (used by menu + browser + concommands)
    --------------------------------------------------------------------

    -- ask the server to switch to a map (must exist on the server, e.g.
    -- inside a hotloaded map addon)
    function TBH.RequestLoadMap(mapname)
        if not isstring(mapname) or mapname == "" then return end

        surface.PlaySound("buttons/button15.wav")
        TBH.NotifyLocally("Requesting map change to \"" .. mapname .. "\"...", 0)

        TBH.Net:Start("loadmap")
        net.WriteString(mapname)
        net.SendToServer()
    end

    -- ask the server to soft-unload a hotloaded addon
    function TBH.RequestUnload(wsid, removeEntities)
        if not TBH.IsValidWSID(wsid) then return end

        TBH.Net:Start("unloadreq")
        net.WriteString(wsid)
        net.WriteBool(removeEntities or false)
        net.SendToServer()
    end

    function TBH.RequestHotload(input, titleHint, autoLoadMap)
        local wsid = TBH.ExtractWSID(input)

        if not wsid then
            TBH.NotifyLocally("That doesn't look like a workshop id or url", 2)
            return false
        end

        -- track it in the session list right away so the player sees what
        -- they requested/hothotloaded/enabled the moment they click
        if not TBH.Client.Known[wsid] then
            TBH.Client.Known[wsid] = {
                title = (titleHint ~= nil and titleHint ~= "" and titleHint) or wsid,
                time = os.time(),
                requested = true,
            }
            TBH.FetchAddonMeta(wsid)
            hook.Run("TBH.ClientListChanged")
        end

        -- remember that this was a LOAD MAP click: when the server finishes
        -- mounting, we automatically ask it to switch levels
        if autoLoadMap then
            TBH.Client.AutoLoadMap[wsid] = true
        end

        surface.PlaySound("buttons/button15.wav")

        TBH.NotifyLocally("Requesting hotload of \"" .. (titleHint ~= "" and titleHint or wsid) .. "\"...", 0)

        TBH.Net:Start("req")
        net.WriteString(wsid)
        net.WriteBool(true)
        net.WriteString(string_sub(tostring(titleHint or ""), 1, 100))
        net.SendToServer()

        return true
    end
end


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  EMBEDDED WEB BROWSER
--
--  A full in-game browser (DHTML/CEF). Whenever you open a Steam Workshop
--  addon page, JavaScript gets injected that drops a big green HOTLOAD
--  button right next to the Subscribe button. Clicking it sends the addon
--  straight into the hotload pipeline.
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

if CLIENT then
    ------------------------------------------------------------------------------
    -- Injected JavaScript (runs on every page the browser loads)
    ------------------------------------------------------------------------------

    local BROWSER_JS = [==[
(function(){
    if (window.__tbhBoys) { return; }
    window.__tbhBoys = true;

    function report() {
        try { tbh.url(location.href, document.title || ''); } catch(e) {}
    }
    report();

    function wsid() {
        var m = (location.href || '').match(/[?&]id=(\d+)/);
        return m ? m[1] : null;
    }

    function cleanTitle() {
        return (document.title || '').replace(/^Steam\s*Workshop::?\s*/, '');
    }

    // a workshop page is a "map addon" when it is tagged Map / Maps / Map Pack
    function isMapPage() {
        try {
            var nodes = document.querySelectorAll('.workshopTags a, .workshopTag, a.tag, .workshopTags');
            for (var i = 0; i < nodes.length; i++) {
                var t = (nodes[i].textContent || '').trim().toLowerCase();
                if (t === 'map' || t === 'maps' || t === 'map pack') return true;
            }
            if (document.querySelector('a[href*="requiredtags%5B%5D=Map"]')) return true;
            if (document.querySelector('a[href*="requiredtags[]=Map"]')) return true;
        } catch(e) {}
        return false;
    }

    var css = document.createElement('style');
    css.textContent = ''
        + '#tbh_hotload_btn{display:inline-block;cursor:pointer;margin:6px 0 4px 0;'
        + 'background:linear-gradient(to bottom,#8fce5a 0%,#5c9e3f 100%);color:#0e1a0c;font-weight:bold;'
        + 'font-family:"Motiva Sans",Arial,sans-serif;font-size:12px;text-transform:uppercase;letter-spacing:.6px;'
        + 'padding:0 14px;height:22px;line-height:22px;border-radius:2px;border:1px solid #3f6d2a;'
        + 'text-decoration:none !important;box-shadow:0 0 8px rgba(140,220,90,.35);}'
        + '#tbh_hotload_btn:hover{filter:brightness(1.15);box-shadow:0 0 14px rgba(140,220,90,.6);}'
        + '#tbh_hotload_btn_fixed{position:fixed;top:10px;right:10px;z-index:999999;display:inline-block;cursor:pointer;'
        + 'background:linear-gradient(to bottom,#8fce5a 0%,#5c9e3f 100%);color:#0e1a0c;font-weight:bold;'
        + 'font-family:"Motiva Sans",Arial,sans-serif;font-size:13px;text-transform:uppercase;letter-spacing:.6px;'
        + 'padding:0 18px;height:28px;line-height:28px;border-radius:3px;border:1px solid #3f6d2a;'
        + 'text-decoration:none !important;box-shadow:0 0 16px rgba(140,220,90,.5);}'
        + '#tbh_hotload_btn_fixed:hover{filter:brightness(1.15);}'
        + '#tbh_flash{position:fixed;top:46px;right:10px;z-index:999999;background:#161414;color:#cfe9b8;'
        + 'padding:8px 12px;border-radius:3px;font:12px Arial;border:1px solid #5c9e3f;}';
    (document.head || document.documentElement).appendChild(css);

    function flash(msg) {
        try {
            var d = document.createElement('div');
            d.id = 'tbh_flash';
            d.textContent = msg;
            document.body.appendChild(d);
            setTimeout(function(){ if (d.parentNode) { d.parentNode.removeChild(d); } }, 2200);
        } catch(e) {}
    }

    function makeButton(fixed) {
        var a = document.createElement('a');
        a.id = fixed ? 'tbh_hotload_btn_fixed' : 'tbh_hotload_btn';
        a.href = 'javascript:void(0)';
        a.title = 'Download and mount this addon instantly with Hotloader';

        a.updateLabel = function() {
            var map = isMapPage();
            a._tbhMap = map;
            a.innerHTML = map
                ? '<span style="font-size:14px">&#128506;</span> LOAD MAP'
                : '<span style="font-size:14px">&#9889;</span> HOTLOAD';
            a.title = map
                ? 'Hotload this map addon and switch the server to it - everyone gets the map'
                : 'Download and mount this addon instantly with Hotloader';
        };
        a.updateLabel();

        a.addEventListener('click', function(ev) {
            ev.preventDefault();
            ev.stopPropagation();
            var id = wsid();
            if (!id) { flash('No addon id found on this page'); return; }
            var map = a._tbhMap || isMapPage();
            try { tbh.hotload(id, cleanTitle(), map); } catch(e) {}
            flash(map ? 'Load-map requested! Switch back to the game.' : 'Hotload requested! Switch back to the game.');
        });
        return a;
    }

    function placedInPage() {
        if (!wsid()) { return false; }
        if (document.getElementById('tbh_hotload_btn')) { return true; }

        var sub = document.querySelector('.general_btn.subscribe') || document.querySelector('#SubscribeItemBtn');
        var host = null;

        if (sub && sub.parentNode) { host = sub.parentNode; }
        if (!host) {
            var rdb = document.querySelector('.rightDetailsBlock');
            if (rdb) { host = rdb; }
        }
        if (!host) {
            var wis = document.querySelector('.workshopItemSubscription');
            if (wis) { host = wis; }
        }

        if (host) {
            var wrap = document.createElement('div');
            wrap.style.margin = '6px 0 4px 0';
            wrap.appendChild(makeButton(false));
            host.appendChild(wrap);
            return true;
        }

        return false;
    }

    var ok = false;
    try { ok = placedInPage(); } catch(e) {}

    if (!ok) {
        setTimeout(function() {
            try {
                if (!document.getElementById('tbh_hotload_btn') &&
                    !document.getElementById('tbh_hotload_btn_fixed') &&
                    wsid() && document.body) {
                    document.body.appendChild(makeButton(true));
                }
            } catch(e) {}
        }, 2500);
    }

    // re-inject when Steam re-renders parts of the page (throttled)
    var last = 0;
    try {
        var mo = new MutationObserver(function() {
            var n = Date.now();
            if (n - last < 600) { return; }
            last = n;
            try { placedInPage(); } catch(e) {}
        });
        mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch(e) {}

    // heartbeat + url change reporting back to Lua
    var lastHref = location.href;
    setInterval(function() {
        if (location.href !== lastHref) {
            lastHref = location.href;
            try { placedInPage(); } catch(e) {}
        }
        // keep the button label in sync (map tag vs regular addon)
        try {
            var b = document.getElementById('tbh_hotload_btn') || document.getElementById('tbh_hotload_btn_fixed');
            if (b && b.updateLabel) { b.updateLabel(); }
        } catch(e) {}
        report();
    }, 3000);
})();
]==]

    ------------------------------------------------------------------------------
    -- Home page (Workshop hub)
    ------------------------------------------------------------------------------

    local HOME_HTML = [==[
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Hotloader Browser</title>
<style>
    body { background:#101410; color:#e2eae2; font-family:"Motiva Sans",Arial,sans-serif; margin:0; }
    .hero { text-align:center; padding:38px 20px 22px; }
    .hero h1 { font-size:34px; margin:0 0 8px; color:#7cd34e; letter-spacing:3px; text-transform:uppercase; text-shadow:0 0 18px rgba(124,211,78,.35); }
    .hero p { color:#94a094; margin:0; font-size:13px; }
    .search { text-align:center; margin:26px 0 8px; }
    .search input { width:440px; max-width:72%; padding:10px 14px; font-size:15px; background:#1a211b; color:#fff; border:1px solid #3a463a; border-radius:3px; outline:none; }
    .search input:focus { border-color:#5c9e3f; }
    .search button { padding:10px 18px; font-size:15px; background:linear-gradient(to bottom,#8fce5a,#5c9e3f); color:#0e1a0c; border:none; border-radius:3px; font-weight:bold; cursor:pointer; }
    .links { max-width:640px; margin:26px auto; }
    .links a { display:block; background:#1a211b; border:1px solid #2c382c; border-radius:4px; padding:14px 16px; text-decoration:none; margin-bottom:10px; }
    .links a:hover { border-color:#5c9e3f; background:#212b21; }
    .links b { color:#e2eae2; font-size:14px; display:block; margin-bottom:4px; }
    .links span { color:#8b978b; font-size:12px; }
    .tip { max-width:640px; margin:20px auto 40px; background:#161d16; border:1px dashed #3f6d2a; border-radius:4px; padding:14px; font-size:13px; color:#cfe9b8; text-align:center; line-height:1.6; }
    .bolt { color:#8fce5a; }
    a { color:#7cd34e; }
</style>
</head>
<body>
<div class="hero">
    <h1>&#9889; Hotloader Browser</h1>
    <p>Browse the Steam Workshop without leaving the game.</p>
</div>
<div class="search">
    <form onsubmit="location.href='https://steamcommunity.com/workshop/browse/?appid=4000&searchtext='+encodeURIComponent(this.q.value); return false;">
        <input name="q" placeholder="Search the Garry's Mod Workshop...">
        <button type="submit">Search</button>
    </form>
</div>
<div id="tbh_featured"></div>
<div class="links">
    <a href="https://steamcommunity.com/workshop/browse/?appid=4000"><b>&#128218; Browse the Workshop</b><span>Every Garry's Mod addon on Steam</span></a>
    <a href="https://steamcommunity.com/workshop/browse/?appid=4000&amp;browsesort=totaluniquesubscribers&amp;section=readytouseitems"><b>&#128293; Most Popular</b><span>All-time most subscribed addons</span></a>
    <a href="https://steamcommunity.com/workshop/browse/?appid=4000&amp;section=collections"><b>&#128230; Collections</b><span>Curated addon packs</span></a>
</div>
<div class="tip">
    <script>
    (function(){
        var pool = [
            { id: '160250458',  name: 'Wiremod',              desc: 'Wire everything to everything' },
            { id: '104548572',  name: 'Playable Piano',       desc: 'The classic piano' },
            { id: '104607228',  name: 'Fire Extinguisher',    desc: 'A fire extinguisher. It extinguishes.' },
            { id: '3787100606', name: 'Featured Favorite',    desc: 'Community pick - watch the green button appear' }
        ];
        var picks = [];
        var copy = pool.slice();
        for (var i = 0; i < 2 && copy.length > 0; i++) {
            picks.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
        }
        var host = document.getElementById('tbh_featured');
        if (host) {
            var html = '<div class="links">';
            for (var j = 0; j < picks.length; j++) {
                var a = picks[j];
                html += '<a href="https://steamcommunity.com/sharedfiles/filedetails/?id=' + a.id + '">'
                     + '<b>&#9889; ' + a.name + '</b><span>' + a.desc + '</span></a>';
            }
            html += '</div>';
            host.innerHTML = html;
        }
    })();
    </script>
    <span class="bolt">&#9889;</span> Open any addon page (<b>steamcommunity.com/sharedfiles/filedetails/?id=...</b>)<br>
    and a big green <b>HOTLOAD</b> button appears next to Subscribe. Click it and the addon<br>
    downloads + mounts on the whole server instantly. You can also paste a URL or a raw addon ID into the address bar.<br><br>
    <span style="color:#8b978b">Pages looking broken or empty? GMod's built-in web engine is ancient.<br>
    Install <a href="https://github.com/solsticegamestudios/GModPatchTool" target="_self">GModPatchTool</a> (optional) for a modern web engine so the browser looks way better.</span>
</div>
</body>
</html>
]==]

    ------------------------------------------------------------------------------
    -- URL helpers
    ------------------------------------------------------------------------------

    function TBH.NormalizeURL(text)
        text = string.Trim(tostring(text or ""))
        if text == "" then return nil end

        -- raw workshop id
        if string_match(text, "^%d+$") then
            return "https://steamcommunity.com/sharedfiles/filedetails/?id=" .. text
        end

        -- full url
        if string_match(text, "^https?://") then
            return text
        end

        -- workshop url without scheme
        if string_match(text, "^steamcommunity%.com") or string_match(text, "^www%.steamcommunity%.com") then
            return "https://" .. text
        end

        -- looks like a domain
        if string_match(text, "^[%w%-%_%.]+%.[%a]+$") or string_match(text, "^[%w%-%_%.]+%.[%a]+/") then
            return "https://" .. text
        end

        -- treat as workshop search terms
        local q = string_gsub(text, "[^%w%s%-%_%%%+%.]", "")
        q = string_gsub(q, "%s+", "+")

        if q == "" then return nil end

        return "https://steamcommunity.com/workshop/browse/?appid=4000&searchtext=" .. q
    end

    function TBH.CleanWorkshopTitle(title)
        if not isstring(title) then return nil end
        local cleaned = string_match(title, "^Steam%s*Workshop::?%s*(.+)$") or title
        cleaned = string_gsub(cleaned, "%s+$", "")
        cleaned = string_gsub(cleaned, "^%s+", "")
        if cleaned == "" then return nil end
        return string_sub(cleaned, 1, 100)
    end

    ------------------------------------------------------------------------------
    -- Browser view panel (toolbar + HTML + status bar, no window chrome)
    --
    -- Used in two places:
    --   * embedded inside the spawnmenu "Web Browser" creation tab
    --   * wrapped inside the popup TBH.Browser DFrame (tbh_browser command)
    ------------------------------------------------------------------------------

    local BrowserCount = 0

    local PANEL = {}

    function PANEL:Init()
        BrowserCount = BrowserCount + 1
        self.BrowserID = BrowserCount

        self.CurrentURL = ""
        self.CurrentTitle = ""

        ----------------------------------------------------------------
        -- Toolbar
        ----------------------------------------------------------------
        local bar = vgui.Create("DPanel", self)
        bar:Dock(TOP)
        bar:SetTall(36)
        bar:DockPadding(4, 5, 4, 5)
        bar.Paint = function(_, w, h)
            draw.RoundedBox(0, 0, 0, w, h, TBH.Colors.bgPanel)
        end

        local function ToolButton(parent, icon, tooltip, text)
            local btn = vgui.Create("DButton", parent)
            btn:SetImage("icon16/" .. icon .. ".png")
            btn:Dock(LEFT)
            btn:SetWide(34)
            btn:SetTooltip(tooltip)
            btn:SetText(text or "")
            btn:SetColor(TBH.Colors.text)
            btn.Paint = function(_, w, h)
                if _:IsHovered() then
                    draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.bgPanel2)
                end
            end
            return btn
        end

        local back = ToolButton(bar, "arrow_left", "Back")
        back.DoClick = function() self:JS("history.back()") end

        local fwd = ToolButton(bar, "arrow_right", "Forward")
        fwd.DoClick = function() self:JS("history.forward()") end

        local refresh = ToolButton(bar, "arrow_refresh", "Reload page")
        refresh.DoClick = function()
            if IsValid(self.HTML) then
                local ok = pcall(function() self.HTML:Refresh() end)
                if not ok then self:JS("location.reload()") end
            end
        end

        local home = ToolButton(bar, "house", "Home (Workshop hub)")
        home.DoClick = function() self:LoadHome() end

        local popout = ToolButton(bar, "application_put", "Open in a separate window (works while the spawnmenu is closed)")
        popout.DoClick = function() TBH.OpenBrowser(self.CurrentURL ~= "" and self.CurrentURL or nil) end

        local hotload = vgui.Create("DButton", bar)
        hotload:Dock(RIGHT)
        hotload:SetWide(120)
        hotload:SetText("HOTLOAD")
        hotload:SetTooltip("Hotload the addon currently open in this page")
        hotload:SetFont("Trebuchet18")
        hotload:SetColor(Color(14, 26, 12))
        hotload.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.accent)
            if _:IsHovered() then
                draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.tag)
            end
        end
        hotload.DoClick = function() self:HotloadCurrentPage() end
        hotload:DockMargin(4, 0, 0, 0)

        self.URL = vgui.Create("DTextEntry", bar)
        self.URL:Dock(FILL)
        self.URL:DockMargin(6, 0, 6, 0)
        self.URL:SetPlaceholderText("Paste a Workshop URL / addon ID, or type search terms and press Enter...")
        self.URL.OnEnter = function(s)
            self:Navigate(s:GetText())
        end

        ----------------------------------------------------------------
        -- HTML view
        ----------------------------------------------------------------
        self.HTML = vgui.Create("DHTML", self)
        self.HTML:Dock(FILL)

        pcall(function()
            self.HTML:AddFunction("tbh", "url", function(url, title)
                self:OnPageURL(url, title)
            end)

            self.HTML:AddFunction("tbh", "hotload", function(id, title, isMap)
                self:OnHotloadID(id, title, isMap)
            end)
        end)

        -- HTML panel callbacks (inherited from the HTML panel class)
        self.HTML.OnDocumentReady = function(_, url)
            self:SetStatus("Page loaded: " .. tostring(url))
            self:JS(BROWSER_JS)
        end

        self.HTML.OnChangeAddressBar = function(_, url)
            if isstring(url) and string_match(url, "^https?://") then
                self.URL:SetText(url)
                self.CurrentURL = url
            end
        end

        self.HTML.OnChangeTitle = function(_, title)
            if isstring(title) and title ~= "" then
                self.CurrentTitle = title

                if isfunction(self.OnTitleChange) then
                    self:OnTitleChange(title)
                end
            end
        end

        self.HTML.OnFinishLoadingDocument = function(_, url)
            if isstring(url) then
                self:SetStatus("Ready - " .. url)
            end
        end

        ----------------------------------------------------------------
        -- Status bar
        ----------------------------------------------------------------
        local status = vgui.Create("DPanel", self)
        status:Dock(BOTTOM)
        status:SetTall(24)
        status.Paint = function(_, w, h)
            draw.RoundedBox(0, 0, 0, w, h, TBH.Colors.bgPanel)
            draw.RoundedBox(0, 0, 0, w, 1, TBH.Colors.outline)
        end

        self.StatusLabel = vgui.Create("DLabel", status)
        self.StatusLabel:Dock(FILL)
        self.StatusLabel:DockMargin(8, 0, 8, 0)
        self.StatusLabel:SetText("Ready")
        self.StatusLabel:SetColor(TBH.Colors.textdim)
        self.StatusLabel:SetFont("DermaDefault")

        self.WorkshopLabel = vgui.Create("DLabel", status)
        self.WorkshopLabel:Dock(RIGHT)
        self.WorkshopLabel:SetText("Hotloader")
        self.WorkshopLabel:SetColor(TBH.Colors.dim)
        self.WorkshopLabel:SizeToContents()
        self.WorkshopLabel:DockMargin(0, 0, 8, 0)

        ----------------------------------------------------------------
        -- Keep bindings + injection alive across page navigations
        ----------------------------------------------------------------
        timer.Create("TBH.Browser" .. self.BrowserID, 1.5, 0, function()
            if not IsValid(self) or not IsValid(self.HTML) then
                timer.Remove("TBH.Browser" .. self.BrowserID)
                return
            end

            pcall(function()
                self.HTML:AddFunction("tbh", "url", function(url, title)
                    self:OnPageURL(url, title)
                end)

                self.HTML:AddFunction("tbh", "hotload", function(id, title, isMap)
                    self:OnHotloadID(id, title, isMap)
                end)
            end)

            self.HTML:QueueJavascript(BROWSER_JS)
        end)

        self:LoadHome()
    end

    function PANEL:OnRemove()
        timer.Remove("TBH.Browser" .. self.BrowserID)
    end

    ------------------------------------------------------------------
    -- Navigation
    ------------------------------------------------------------------

    function PANEL:JS(code)
        if IsValid(self.HTML) then
            self.HTML:RunJavascript(code)
        end
    end

    function PANEL:SetStatus(text)
        if IsValid(self.StatusLabel) then
            self.StatusLabel:SetText(string_sub(tostring(text), 1, 120))
        end
    end

    function PANEL:LoadHome()
        self.CurrentURL = ""
        self:SetStatus("Home - Workshop hub")

        if isfunction(self.OnTitleChange) then
            self:OnTitleChange("Hotloader Browser")
        end

        if IsValid(self.HTML) then
            self.HTML:SetHTML(HOME_HTML)
        end

        if IsValid(self.URL) then
            self.URL:SetText("")
        end
    end

    function PANEL:Navigate(text)
        local url = TBH.NormalizeURL(text)

        if not url then
            self:SetStatus("Only http/https pages can be opened here")
            return
        end

        if not string_match(url, "^https?://") then
            self:SetStatus("Only http/https pages can be opened here")
            return
        end

        self.CurrentURL = url
        self:SetStatus("Loading " .. url .. " ...")

        if IsValid(self.HTML) then
            self.HTML:OpenURL(url)
        end

        if IsValid(self.URL) then
            self.URL:SetText(url)
        end
    end

    ------------------------------------------------------------------
    -- JS callbacks
    ------------------------------------------------------------------

    function PANEL:OnPageURL(url, title)
        if isstring(url) and string_match(url, "^https?://") then
            self.CurrentURL = url
            self.URL:SetText(url)

            if isstring(title) and title ~= "" then
                self.CurrentTitle = title

                if isfunction(self.OnTitleChange) then
                    self:OnTitleChange(title)
                end
            end
        end
    end

    function PANEL:OnHotloadID(id, title, isMap)
        local wsid = TBH.ExtractWSID(id)

        if not wsid then
            TBH.NotifyLocally("Browser: could not find an addon id on that page", 2)
            return
        end

        local clean = TBH.CleanWorkshopTitle(title)
        TBH.RequestHotload(wsid, clean or "", isMap == true)
    end

    function PANEL:HotloadCurrentPage()
        local wsid = TBH.ExtractWSID(self.CurrentURL) or TBH.ExtractWSID(self.URL:GetText())

        if not wsid then
            TBH.NotifyLocally("Open a Workshop addon page first!", 2)
            return
        end

        local clean = TBH.CleanWorkshopTitle(self.CurrentTitle)
        TBH.RequestHotload(wsid, clean or "")
    end

    vgui.Register("TBH.BrowserPanel", PANEL, "EditablePanel")

    ------------------------------------------------------------------------------
    -- Popup browser window (wraps the browser view in a DFrame)
    ------------------------------------------------------------------------------

    local FRAME = {}

    function FRAME:Init()
        self:SetTitle("  Hotloader Browser")
        self:SetSize(math.min(ScrW() - 60, 1060), math.min(ScrH() - 60, 700))
        self:Center()
        self:SetSizable(true)
        self:SetMinWidth(620)
        self:SetMinHeight(400)
        self:MakePopup()

        self.View = vgui.Create("TBH.BrowserPanel", self)
        self.View:Dock(FILL)

        self.View.OnTitleChange = function(_, title)
            self:SetTitle("  " .. string_sub(title, 1, 60))
        end
    end

    function FRAME:Navigate(text)
        if IsValid(self.View) then
            self.View:Navigate(text)
        end
    end

    function FRAME:OnRemove()
        if TBH.BrowserPanel == self then
            TBH.BrowserPanel = nil
        end
    end

    vgui.Register("TBH.Browser", FRAME, "DFrame")

    ------------------------------------------------------------------------------
    -- Browser openers
    ------------------------------------------------------------------------------

    function TBH.OpenBrowser(url)
        if IsValid(TBH.BrowserPanel) then
            TBH.BrowserPanel:SetVisible(true)
            TBH.BrowserPanel:MoveToFront()

            if url then
                TBH.BrowserPanel:Navigate(url)
            end

            return TBH.BrowserPanel
        end

        local frame = vgui.Create("TBH.Browser")
        TBH.BrowserPanel = frame

        if url then
            frame:Navigate(url)
        end

        return frame
    end

    -- opens the popup browser from inside the spawnmenu (buttons, context
    -- menus): closes the spawnmenu first so the window is front and center
    function TBH.OpenBrowserFromMenu(url)
        gui.HideGameUI()

        local frame = TBH.OpenBrowser(url)

        if IsValid(frame) then
            frame:MoveToFront()
        end

        return frame
    end
end


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  SPAWNMENU UI + SETTINGS + COMMANDS + HINTS
--
--  * Q menu creation tab: "Hotloader"
--  * Utilities -> Hotloader -> Settings & Info
--  * Console commands, welcome hints, boot messages
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

if CLIENT then
    ------------------------------------------------------------------------------
    -- Fonts
    ------------------------------------------------------------------------------

    surface.CreateFont("TBH.Hero", { font = "Roboto Bk", size = 34, weight = 900, extended = true })
    surface.CreateFont("TBH.Header", { font = "Roboto Bk", size = 20, weight = 900, extended = true })
    surface.CreateFont("TBH.Body", { font = "Roboto", size = 15, weight = 500, extended = true })
    surface.CreateFont("TBH.Small", { font = "Roboto", size = 13, weight = 400, extended = true })
    surface.CreateFont("TBH.Mono", { font = "Roboto", size = 13, weight = 500, extended = true })
    surface.CreateFont("TBH.Status", { font = "Roboto", size = 14, weight = 400, extended = true })

    ------------------------------------------------------------------------------
    -- Server info handshake (module status, permission level, ...)
    ------------------------------------------------------------------------------

    TBH.ServerInfo = nil

    timer.Simple(5, function()
        TBH.Net:Start("hello")
        net.SendToServer()
    end)

    TBH.Net:Receive("info", function()
        TBH.ServerInfo = {
            permission = net.ReadUInt(8),
            requirements = net.ReadBool(),
            module = net.ReadBool(),
            mounted = net.ReadUInt(16),
            version = net.ReadString(),
        }
        hook.Run("TBH.ClientListChanged")
    end)

    ------------------------------------------------------------------------------
    -- The main menu page (used in the spawnmenu tab AND the tbh_menu window)
    ------------------------------------------------------------------------------

    local PageCount = 0

    local PANEL = {}

    function PANEL:Init()
        PageCount = PageCount + 1
        self.PageID = PageCount

        -- NOTE: this panel is based on EditablePanel (a raw panel, NOT a
        -- DPanel) - it has no SetPaintBackground/SetPaintBorder methods, and
        -- raw panels paint no background by default, so nothing to disable.

        self.RefreshHook = "TBH.MenuPage" .. self.PageID

        hook.Add("TBH.ClientListChanged", self.RefreshHook, function()
            if IsValid(self) then self:RefreshList() end
        end)

        hook.Add("TBH.StatusLogged", self.RefreshHook, function()
            if IsValid(self) then self:RefreshStatus() end
        end)

        ----------------------------------------------------------------
        -- Hero header
        ----------------------------------------------------------------
        local hero = vgui.Create("DPanel", self)
        hero:Dock(TOP)
        hero:SetTall(84)
        hero:DockMargin(0, 0, 0, 8)
        hero.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)

            -- accent corner
            draw.RoundedBoxEx(6, 0, 0, 6, h, TBH.Colors.accent, true, false, true, false)

            draw.SimpleText("HOTLOADER", "TBH.Hero", 22, 16, TBH.Colors.tag, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("Hotload any Workshop addon mid-game. No restart. No reboot.", "TBH.Body", 22, 50, TBH.Colors.textdim)
            draw.SimpleText("v" .. TBH.Version, "TBH.Small", w - 14, 12, TBH.Colors.dim, TEXT_ALIGN_RIGHT)
        end

        ----------------------------------------------------------------
        -- Hotload input row
        ----------------------------------------------------------------
        local row = vgui.Create("DPanel", self)
        row:Dock(TOP)
        row:SetTall(42)
        row:DockMargin(0, 0, 0, 8)
        row.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)
        end

        self.Input = vgui.Create("DTextEntry", row)
        self.Input:Dock(FILL)
        self.Input:DockMargin(8, 8, 8, 8)
        self.Input:SetPlaceholderText("Paste a Workshop URL or addon ID (e.g. 3787100606) and smash the button...")
        self.Input:SetFont("TBH.Body")
        self.Input.OnEnter = function(s)
            self:SubmitHotload()
        end

        local go = vgui.Create("DButton", row)
        go:Dock(RIGHT)
        go:SetWide(140)
        go:DockMargin(0, 8, 8, 8)
        go:SetText("HOTLOAD")
        go:SetFont("TBH.Header")
        go:SetColor(Color(14, 26, 12))
        go.DoClick = function() self:SubmitHotload() end
        go.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.accent)
            if _:IsHovered() then
                draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.tag)
            end
        end

        local browserBtn = vgui.Create("DButton", row)
        browserBtn:Dock(RIGHT)
        browserBtn:SetWide(130)
        browserBtn:DockMargin(0, 8, 0, 8)
        browserBtn:SetText("  HOTLOADER BROWSER")
        browserBtn:SetImage("icon16/world.png")
        browserBtn:SetFont("TBH.Body")
        browserBtn:SetColor(TBH.Colors.text)
        browserBtn:SetTooltip("Open the built-in browser - visit any addon page for a HOTLOAD button")
        browserBtn.DoClick = function() TBH.OpenBrowserFromMenu() end
        browserBtn.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.bgPanel2)
            if _:IsHovered() then
                draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.outline)
            end
        end

        ----------------------------------------------------------------
        -- Auto-hotload checkboxes (each says exactly what it does -
        -- hover a checkbox for the full explanation)
        ----------------------------------------------------------------
        local checks = vgui.Create("DPanel", self)
        checks:Dock(TOP)
        checks:SetTall(58)
        checks:DockMargin(0, 0, 0, 8)
        checks.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)
        end

        local function StyleCheckbox(cb, text, convar, tooltip)
            cb:Dock(TOP)
            cb:SetTall(22)
            cb:DockMargin(12, 6, 12, 0)
            cb:SetText(text)
            cb:SetConVar(convar)
            cb:SetTooltip(tooltip)

            -- label styling (different Derma versions expose these differently)
            pcall(function() cb:SetFont("TBH.Small") end)
            pcall(function() cb:SetTextColor(TBH.Colors.text) end)

            if cb.Label then
                pcall(function() cb.Label:SetFont("TBH.Small") end)
                pcall(function() cb.Label:SetTextColor(TBH.Colors.text) end)
            end
        end

        local sub = vgui.Create("DCheckBoxLabel", checks)
        StyleCheckbox(sub, "Auto-Hotload on Subscribe", "tbh_autosubscribe",
            "Subscribing to addon will auto hotload")

        local ena = vgui.Create("DCheckBoxLabel", checks)
        StyleCheckbox(ena, "Enable Addons", "tbh_enableaddons",
            "Enables Addons from Addon Menu")

        ----------------------------------------------------------------
        -- Layout
        --
        -- FIXED at the top: hero / input row / checkboxes / activity feed.
        -- FILL below: the session list scroll. The list has its OWN
        -- DScrollPanel, so as soon as you hotload enough addons that the
        -- cards no longer fit, a scrollbar appears on the list itself.
        -- (All children everywhere are docked TOP - bottom-docking inside a
        -- scroll canvas breaks the scroll extent.)
        ----------------------------------------------------------------
        local function TopPanel(parent, tall)
            local p = vgui.Create("DPanel", parent)
            p:Dock(TOP)
            p:SetTall(tall)
            return p
        end

        ----------------------------------------------------------------
        -- Status feed (fixed)
        ----------------------------------------------------------------
        local statusHeader = TopPanel(self, 26)
        statusHeader.Paint = function(_, w, h)
            draw.SimpleText("ACTIVITY", "TBH.Small", 8, 4, TBH.Colors.dim)
        end

        self.StatusPanel = TopPanel(self, 80)
        self.StatusPanel:DockMargin(0, 0, 0, 8)
        self.StatusPanel.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)
            self:PaintStatus(w, h)
        end

        ----------------------------------------------------------------
        -- Session list
        ----------------------------------------------------------------
        local listHeader = TopPanel(self, 26)
        listHeader.Paint = function(_, w, h)
            draw.SimpleText("YOUR ADDONS THIS SESSION", "TBH.Small", 8, 4, TBH.Colors.dim)
            draw.SimpleText("(everything you hotload, enable or request shows up here)", "TBH.Small", w - 8, 4, TBH.Colors.dim, TEXT_ALIGN_RIGHT)
        end

        -- the session list scroll: scrollbar appears automatically once
        -- the addon cards outgrow the visible area (2+ big cards, etc.)
        self.ListScroll = vgui.Create("DScrollPanel", self)
        self.ListScroll:Dock(FILL)

        self.ListPanel = TopPanel(self.ListScroll, 10)
        self.ListPanel.Paint = nil

        ----------------------------------------------------------------
        -- Footer
        ----------------------------------------------------------------
        local footer = TopPanel(self.ListScroll, 52)
        footer:DockMargin(0, 8, 0, 0)
        footer.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)

            local info = TBH.ServerInfo
            local moduleText, moduleColor

            if info == nil then
                moduleText = "server info: waiting..."
                moduleColor = TBH.Colors.textdim
            elseif info.module then
                moduleText = "gmsv_workshop module: LOADED"
                moduleColor = TBH.Colors.ok
            elseif info.mounted > 0 then
                moduleText = "gmsv_workshop module: not installed (host-routed downloads)"
                moduleColor = TBH.Colors.warn
            else
                moduleText = "gmsv_workshop module: MISSING"
                moduleColor = TBH.Colors.error
            end

            draw.SimpleText(moduleText, "TBH.Small", 12, 8, moduleColor)
            draw.SimpleText("Arch. inspired by Midgame Workshop Hotloader (Xalalau) - rewritten from scratch", "TBH.Small", 12, h - 20, TBH.Colors.dim)
            draw.SimpleText("tbh_browser | tbh_hotload <id> | tbh_resync", "TBH.Small", w - 12, 8, TBH.Colors.dim, TEXT_ALIGN_RIGHT)
        end

        self:RefreshStatus()
        self:RefreshList()
    end

    function PANEL:OnRemove()
        hook.Remove("TBH.ClientListChanged", self.RefreshHook)
        hook.Remove("TBH.StatusLogged", self.RefreshHook)
    end

    function PANEL:SubmitHotload()
        local text = self.Input:GetText()
        TBH.RequestHotload(text, "")

        if TBH.ExtractWSID(text) then
            self.Input:SetText("")
        end
    end

    ------------------------------------------------------------------
    -- Status feed painting
    ------------------------------------------------------------------

    function PANEL:PaintStatus(w, h)
        local log = TBH.StatusLog or {}
        local shown = math.min(#log, 5)
        if shown == 0 then
            draw.SimpleText("Nothing yet - paste an addon URL above, or open the web browser and go hunting.", "TBH.Status", 12, h / 2 - 8, TBH.Colors.textdim)
            return
        end

        local y = 8
        for i = #log - shown + 1, #log do
            local entry = log[i]
            local color = TBH.Colors.text

            if entry.level == 1 then color = TBH.Colors.ok end
            if entry.level == 2 then color = TBH.Colors.error end
            if entry.level == 3 then color = TBH.Colors.warn end

            local msg = entry.msg or ""
            if #msg > 90 then msg = string_sub(msg, 1, 90) .. "..." end

            draw.SimpleText("> " .. msg, "TBH.Status", 12, y, color)
            y = y + 17
        end
    end

    function PANEL:RefreshStatus()
        -- the paint function reads TBH.StatusLog live; just force repaint
        if IsValid(self.StatusPanel) then
            self.StatusPanel:InvalidateLayout(true)
        end
    end

    ------------------------------------------------------------------
    -- Session list
    ------------------------------------------------------------------

    function PANEL:RefreshList()
        if not IsValid(self.ListPanel) then return end

        self.ListPanel:Clear()

        local entries = {}

        for wsid, data in pairs(TBH.Client.Known or {}) do
            entries[#entries + 1] = {
                wsid = wsid,
                title = data.title or wsid,
                time = data.time or 0,
            }
        end

        table.sort(entries, function(a, b) return (a.time or 0) > (b.time or 0) end)

        if #entries == 0 then
            local empty = vgui.Create("DPanel", self.ListPanel)
            empty:Dock(TOP)
            empty:SetTall(72)
            empty.Paint = function(_, w, h)
                draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)
                draw.SimpleText("No addons hotloaded yet.", "TBH.Body", w / 2, 14, TBH.Colors.textdim, TEXT_ALIGN_CENTER)
                draw.SimpleText("Be the first. Paste a URL above or raid the Workshop with the browser.", "TBH.Small", w / 2, 36, TBH.Colors.dim, TEXT_ALIGN_CENTER)
            end
            self.ListPanel:SetTall(56)
            return
        end

        local height = 0
        local maxRows = 12

        for i = 1, math.min(#entries, maxRows) do
            local entry = entries[i]
            local row = self:CreateAddonRow(entry, self.ListPanel)
            row:Dock(TOP)
            height = height + row:GetTall() + 4
        end

        if #entries > maxRows then
            height = height + 24
            local more = vgui.Create("DPanel", self.ListPanel)
            more:Dock(TOP)
            more:SetTall(20)
            more.Paint = function(_, w, h)
                draw.SimpleText("...and " .. (#entries - maxRows) .. " more (tbh_list prints everything)", "TBH.Small", 10, 2, TBH.Colors.dim)
            end
        end

        self.ListPanel:SetTall(math.max(height, 10))
    end

    function PANEL:CreateAddonRow(entry, parent)
        local row = vgui.Create("DPanel", parent)
        row:SetTall(86)
        row.wsid = entry.wsid
        row.title = entry.title
        row.RightPad = 12

        local meta = TBH.Client.Meta and TBH.Client.Meta[entry.wsid]
        local displayTitle = (meta and meta.title) or entry.title or entry.wsid
        row.title = displayTitle

        local mounted = TBH.Client.Mounted and TBH.Client.Mounted[entry.wsid]
        local maps = (istable(mounted) and istable(mounted.maps) and #mounted.maps > 0 and mounted.maps)
            or (istable(entry.maps) and #entry.maps > 0 and entry.maps)
            or nil

        local function OpenUnloadDialogFromRow(selfRow)
            Derma_Query(
                "Soft-unload \"" .. selfRow.title .. "\"?\n\n" ..
                "REMOVED: hooks, timers, spawnmenu entries" .. "\n" ..
                "KEPT: mounted files (GMod cannot unmount) - restart fully clears them",
                "Hotloader",
                "Unload", function()
                    TBH.RequestUnload(selfRow.wsid, false)
                end,
                "Unload + remove its entities", function()
                    TBH.RequestUnload(selfRow.wsid, true)
                end,
                "Cancel", function() end
            )
        end

        ----------------------------------------------------------------
        -- Thumbnail (workshop preview image, downloaded + cached)
        ----------------------------------------------------------------
        local thumb = vgui.Create("DPanel", row)
        thumb:Dock(LEFT)
        thumb:SetWide(124)
        thumb:DockMargin(8, 8, 0, 8)
        local metaState = TBH.Client.Meta and TBH.Client.Meta[entry.wsid]

        thumb.Paint = function(_, w, h)
            draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.bgPanel2)
            draw.RoundedBoxEx(4, 0, 0, 4, h, TBH.Colors.dim, true, false, true, false)
            -- placeholder until the preview image arrives
            draw.SimpleText(string_sub(displayTitle, 1, 14), "TBH.Small", w / 2, h / 2 - 8, TBH.Colors.textdim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            local sub = "preview loading..."

            if metaState and (metaState.imageFailed or metaState.failed) then
                sub = "no preview available"
            end

            draw.SimpleText(sub, "TBH.Small", w / 2, h / 2 + 10, TBH.Colors.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local imageMat = TBH.GetAddonImage(entry.wsid)

        if imageMat then
            local img = vgui.Create("DImage", thumb)
            img:Dock(FILL)
            img:SetMaterial(imageMat)
            img:SetKeepAspect(true)
        end

        ----------------------------------------------------------------
        -- Buttons
        ----------------------------------------------------------------
        if maps and not (istable(mounted) and mounted.unloaded) then
            local mapBtn = vgui.Create("DButton", row)
            mapBtn:Dock(RIGHT)
            mapBtn:SetWide(100)
            mapBtn:DockMargin(0, 8, 8, 8)
            mapBtn:SetText(#maps == 1 and "LOAD MAP" or "MAPS (" .. #maps .. ")")
            mapBtn:SetFont("TBH.Small")
            mapBtn:SetColor(Color(14, 26, 12))
            mapBtn:SetTooltip(#maps == 1
                and ("Switch the server to the map \"" .. maps[1] .. "\" - everyone has it!")
                or "Pick a map to switch the server to")
            mapBtn.Paint = function(_, w, h)
                draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.accent)
                if _:IsHovered() then
                    draw.RoundedBox(4, 0, 0, w, h, TBH.Colors.tag)
                end
            end
            mapBtn.DoClick = function()
                if #maps == 1 then
                    TBH.RequestLoadMap(maps[1])
                else
                    local menu = DermaMenu()
                    menu:AddSpacer()

                    for i = 1, math.min(#maps, 20) do
                        menu:AddOption(maps[i], function()
                            TBH.RequestLoadMap(maps[i])
                        end):SetIcon("icon16/map.png")
                    end

                    menu:Open()
                end
            end

            row.RightPad = row.RightPad + 108
        end

        -- UNLOAD button - always visible on every row (soft unload)
        if not (istable(mounted) and mounted.unloaded) then
            local unloadBtn = vgui.Create("DButton", row)
            unloadBtn:Dock(RIGHT)
            unloadBtn:SetWide(88)
            unloadBtn:DockMargin(0, 8, 6, 8)
            unloadBtn:SetText("UNLOAD")
            unloadBtn:SetFont("TBH.Small")
            unloadBtn:SetColor(Color(255, 226, 226))
            unloadBtn:SetTooltip("Soft-unload this addon: removes its hooks, timers and menu entries (optionally its entities). The mounted FILES stay - GMod cannot unmount, only a restart clears them.")
            unloadBtn.Paint = function(_, w, h)
                draw.RoundedBox(4, 0, 0, w, h, Color(122, 44, 44))
                if _:IsHovered() then
                    draw.RoundedBox(4, 0, 0, w, h, Color(168, 62, 62))
                end
            end
            unloadBtn.DoClick = function() OpenUnloadDialogFromRow(row) end

            row.RightPad = row.RightPad + 94
        end

        ----------------------------------------------------------------
        -- Card painting
        ----------------------------------------------------------------
        row.Paint = function(selfRow, w, h)
            draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel)

            if selfRow:IsHovered() then
                draw.RoundedBox(6, 0, 0, w, h, TBH.Colors.bgPanel2)
            end

            local mounted = TBH.Client.Mounted and TBH.Client.Mounted[selfRow.wsid]
            local queued = false
            if TBH.Client.Queue then
                for i = 1, #TBH.Client.Queue do
                    if TBH.Client.Queue[i].wsid == selfRow.wsid then queued = true break end
                end
            end

            local dotColor, stateText

            if istable(mounted) and mounted.unloaded then
                dotColor = TBH.Colors.textdim
                stateText = "unloaded (Lua off, content stays)"
            elseif mounted then
                dotColor = TBH.Colors.ok
                stateText = mounted.files .. " files"

                if istable(mounted.maps) and #mounted.maps > 0 then
                    stateText = #mounted.maps .. " map(s)"
                end

                if (mounted.errors or 0) > 0 then
                    dotColor = TBH.Colors.warn
                    stateText = stateText .. " - " .. mounted.errors .. " errors"
                end
            elseif queued then
                dotColor = TBH.Colors.info
                stateText = "downloading..."
            elseif istable(TBH.Client.Known[selfRow.wsid]) and TBH.Client.Known[selfRow.wsid].requested then
                dotColor = TBH.Colors.info
                stateText = "requested - waiting for server..."
            else
                dotColor = TBH.Colors.warn
                stateText = "not synced yet"
            end

            local left = 142
            local rightX = w - (selfRow.RightPad or 12)

            draw.RoundedBox(4, left, 10, 8, 8, dotColor)

            draw.SimpleText(displayTitle, "TBH.Body", left + 16, 8, TBH.Colors.text)

            -- author line ("By <author>" from the workshop page)
            local meta = TBH.Client.Meta and TBH.Client.Meta[selfRow.wsid]
            local authorText = "wsid " .. selfRow.wsid

            if meta and meta.author then
                authorText = "By " .. meta.author .. "  -  " .. authorText
            end

            draw.SimpleText(authorText, "TBH.Small", left, 30, TBH.Colors.textdim)

            draw.SimpleText(stateText, "TBH.Small", rightX, 12, dotColor, TEXT_ALIGN_RIGHT)

            if mounted and not mounted.unloaded then
                local t = os.date("%H:%M", mounted.time or os.time())
                draw.SimpleText(t, "TBH.Small", rightX, 30, TBH.Colors.dim, TEXT_ALIGN_RIGHT)
            end
        end

        row.OnMousePressed = function(selfRow, code)
            if code == MOUSE_LEFT then
                SetClipboardText(selfRow.wsid)
                TBH.NotifyLocally("Workshop ID " .. selfRow.wsid .. " copied to clipboard", 0)
            elseif code == MOUSE_RIGHT then
                local menu = DermaMenu()

                menu:AddOption("Copy Workshop ID", function()
                    SetClipboardText(selfRow.wsid)
                    TBH.NotifyLocally("Workshop ID copied", 0)
                end):SetIcon("icon16/page_copy.png")

                menu:AddOption("Copy Workshop URL", function()
                    SetClipboardText(TBH.WorkshopURL(selfRow.wsid))
                    TBH.NotifyLocally("Workshop URL copied", 0)
                end):SetIcon("icon16/link.png")

                menu:AddOption("Open page in Hotloader Browser", function()
                    TBH.OpenBrowserFromMenu(TBH.WorkshopURL(selfRow.wsid))
                end):SetIcon("icon16/world.png")

                menu:AddOption("Request re-hotload", function()
                    TBH.RequestHotload(selfRow.wsid, selfRow.title)
                end):SetIcon("icon16/arrow_refresh.png")

                local rowMounted = TBH.Client.Mounted and TBH.Client.Mounted[selfRow.wsid]
                local rowMaps = (istable(rowMounted) and istable(rowMounted.maps) and #rowMounted.maps > 0 and rowMounted.maps)
                    or (istable(entry.maps) and #entry.maps > 0 and entry.maps)
                    or nil

                if rowMaps then
                    menu:AddSpacer()

                    for i = 1, math.min(#rowMaps, 20) do
                        menu:AddOption("Load map: " .. rowMaps[i], function()
                            TBH.RequestLoadMap(rowMaps[i])
                        end):SetIcon("icon16/map.png")
                    end
                end

                if not (istable(rowMounted) and rowMounted.unloaded) then
                    menu:AddSpacer()

                    menu:AddOption("Unload (remove Lua, keep content)", function()
                        OpenUnloadDialogFromRow(selfRow)
                    end):SetIcon("icon16/cross.png")
                end

                menu:Open()
            end
        end

        row:SetTooltip("Left click: copy ID - Right click: options")

        return row
    end

    vgui.Register("TBH.MenuPage", PANEL, "EditablePanel")

    ------------------------------------------------------------------------------
    -- Spawnmenu creation tabs (top tab row: Spawnlists/Weapons/.../Saves)
    --
    -- The creation menu reads spawnmenu.GetCreationTabs() when the spawnmenu
    -- is BUILT, so tabs must be registered BEFORE that. Two paths:
    --   1. file scope (if the spawnmenu module is loaded already)
    --   2. the AddToolMenuTabs hook - guaranteed to run inside
    --      CreateSpawnMenu() BEFORE the CreationMenu is populated, and it
    --      re-runs on every spawnmenu_reload. (There is NO "PopulateSpawnMenu"
    --      hook in GMod - that was a dead end.)
    -- Re-registering is safe: tabs are keyed by name.
    ------------------------------------------------------------------------------

    local function RegisterSpawnTabs()
        spawnmenu.AddCreationTab("Hotloader", function()
            local page = vgui.Create("TBH.MenuPage")
            page:DockPadding(8, 8, 8, 8)
            return page
        end, "icon16/lightning.png", 300, "Hotloader - hotload any Workshop addon mid-game")

        spawnmenu.AddCreationTab("Hotloader Browser", function()
            local page = vgui.Create("EditablePanel")
            page:DockPadding(6, 6, 6, 6)

            local browser = vgui.Create("TBH.BrowserPanel", page)
            browser:Dock(FILL)

            return page
        end, "icon16/world.png", 301, "Hotloader Browser - browse the Workshop, hotload from any addon page")
    end

    -- path 1: register immediately if possible
    pcall(RegisterSpawnTabs)

    -- path 2: guaranteed slot (runs before the creation menu is built, every
    -- time - initial load AND spawnmenu_reload)
    hook.Add("AddToolMenuTabs", "TBH.SpawnMenuTab", RegisterSpawnTabs)

    ------------------------------------------------------------------------------
    -- Utilities settings
    ------------------------------------------------------------------------------

    hook.Add("AddToolMenuCategories", "TBH.ToolCategories", function()
        spawnmenu.AddToolCategory("Utilities", "Hotloader", "Hotloader")
    end)

    hook.Add("PopulateToolMenu", "TBH.ToolMenuOptions", function()
        spawnmenu.AddToolMenuOption("Utilities", "Hotloader", "tbh_settings", "Settings & Info", "", "", function(panel)
            panel:ClearControls()

            panel:Help("Hotloader v" .. TBH.Version .. " - hotload any Workshop addon mid-game.")

            local info = TBH.ServerInfo

            if info then
                local permText = "everyone"
                if info.permission == 1 then permText = "admins" end
                if info.permission == 2 then permText = "superadmins" end

                panel:Help("Server: permission level \"" .. permText .. "\", requirement chains " ..
                    (info.requirements and "ON" or "OFF") .. ", module " ..
                    (info.module and "LOADED" or "missing") .. ", " .. info.mounted .. " addon(s) hotloaded.")
            else
                panel:Help("Waiting for server info...")
            end

            panel:Help("Change server settings with: tbh_permission, tbh_requirements, tbh_max_files, tbh_timeout, tbh_cooldown, tbh_latesync, tbh_announce")

            panel:Help("The browser lives in its own spawnmenu tab (top row, next to Saves/Dupes). You can also pop it out:")
            panel:Button("Open Hotloader Browser in a window", "tbh_browser")
            panel:Button("Re-sync all hotloaded addons", "tbh_resync")
            panel:Button("Show welcome hints again", "tbh_give_hints")

            panel:Help("AUTO-HOTLOAD (client checkboxes - also in the hotloader tab):")
            panel:CheckBox("Auto-Hotload on Subscribe", "tbh_autosubscribe")
            panel:CheckBox("Enable Addons", "tbh_enableaddons")
            panel:CheckBox("Welcome hints", "tbh_hints")
            panel:CheckBox("Verbose hotload logs in console (client)", "tbh_logs")

            panel:Help("Tip: hotloaded tools appear in the tool menu after the spawnmenu refreshes; new weapons/entities appear in their spawn tabs. If a tool is missing from the list you can still select it with: gmod_tool <toolname>")

            panel:Help("OPTIONAL: GModPatchTool gives GMod a modern web engine so Hotloader Browser renders pages properly - works fine without it, looks way better with it: https://github.com/solsticegamestudios/GModPatchTool")
			
			panel:Help("Auto-Hotload on Subscribe: Hotloads Addons that you subbed too!")
			panel:Help("Enable Addons: Enable A Addon from the menu via esc and press Enable and it will hotload it for you!")
			panel:Help("Welcome Hints: Disable's Hints From Showing! (restart to take effect)")
        end)
    end)

    ------------------------------------------------------------------------------
    -- Console commands (client side)
    ------------------------------------------------------------------------------

    concommand.Add("tbh_browser", function(ply, cmd, args)
        local url = table.concat(args or {}, " ")
        TBH.OpenBrowser(url ~= "" and url or nil)
    end)

    concommand.Add("tbh_menu", function()
        local frame = vgui.Create("DFrame")
        frame:SetTitle("  Hotloader")
        frame:SetSize(math.min(ScrW() - 60, 760), math.min(ScrH() - 60, 640))
        frame:Center()
        frame:MakePopup()
        frame:SetSizable(true)
        frame:SetDeleteOnClose(true)

        local page = vgui.Create("TBH.MenuPage", frame)
        page:Dock(FILL)
        page:DockPadding(10, 10, 10, 10)
    end)

    concommand.Add("tbh_list", function()
        local known = TBH.Client.Known or {}
        local count = 0

        MsgC(TBH.Colors.tag, "\n[Hotloader] session addons:\n")

        for wsid, data in pairs(known) do
            count = count + 1
            local mounted = TBH.Client.Mounted and TBH.Client.Mounted[wsid]
            local state = mounted and ("mounted, " .. mounted.files .. " files") or "not synced"
            MsgC(TBH.Colors.textdim, "  ", TBH.Colors.text, wsid, TBH.Colors.textdim, " - " .. (data.title or "?") .. " (" .. state .. ")\n")
        end

        if count == 0 then
            MsgC(TBH.Colors.textdim, "  nothing yet\n")
        end

        MsgC(TBH.Colors.tag, "\n")
    end)

    concommand.Add("tbh_resync", function()
        TBH.Net:Start("resync")
        net.SendToServer()
        TBH.NotifyLocally("Requesting the addon list from the server...", 0)
    end)

    ------------------------------------------------------------------------------
    -- Welcome hints (shared by the boot sequence and tbh_give_hints)
    ------------------------------------------------------------------------------

    local HINTS = {
        "Welcome to Hotloader v" .. TBH.Version .. "! Press Q - the 'Hotloader' and 'Web Browser' tabs are in the top tab row (next to Saves).",
        "The Web Browser tab surfs the Workshop - every addon page gets a green button: HOTLOAD, or LOAD MAP on map addons.",
        "Subscribe to a Workshop addon in the Steam overlay and it hotloads automatically (tbh_autosubscribe).",
        "Turn an addon back ON in the Addons menu and it hotloads instantly (tbh_enableaddons) - it's already downloaded.",
        "Hotloaded a map addon? Hit LOAD MAP - the server switches and everyone gets the map.",
        "Browser pages look broken? GMod's web engine is old - install GModPatchTool (optional).",
        "The UNLOAD button on each addon removes its hooks/timers/menus (files stay mounted - GMod can't unmount).",
        "Right-click an addon in the session list for more options. Disable hints with tbh_hints 0.",
    }

    concommand.Add("tbh_give_hints", function()
        for i = 1, #HINTS do
            notification.AddLegacy("[Hotloader] " .. HINTS[i], NOTIFY_GENERIC, 8)
        end
    end)

    if TBH.CVarHints and TBH.CVarHints:GetBool() then
        local schedule = { 8, 16, 24, 32, 40, 50, 60, 70 }

        for i = 1, #HINTS do
            local delay = schedule[i] or (8 + i * 9)

            timer.Simple(delay, function()
                if TBH.CVarHints and TBH.CVarHints:GetBool() then
                    surface.PlaySound("buttons/button15.wav")
                    notification.AddLegacy("[Hotloader] " .. HINTS[i], NOTIFY_GENERIC, 8)
                end
            end)
        end
    end

    ------------------------------------------------------------------------------
    -- Client boot message
    ------------------------------------------------------------------------------

    timer.Simple(6, function()
        MsgC(TBH.Colors.tag, "\n[Hotloader] v" .. TBH.Version .. " loaded (CLIENT)\n")
        MsgC(TBH.Colors.text, "[Hotloader] Q -> 'Hotloader' + 'Web Browser' tabs (top row) | tbh_browser | tbh_hotload <id> | subscribe/enable = auto-hotload | maps = LOAD MAP\n\n")
    end)
end

--------------------------------------------------------------------------------
-- Shared console commands (server-realm parts)
--------------------------------------------------------------------------------

if SERVER then
    concommand.Add("tbh_hotload", function(ply, cmd, args)
        local input = args and args[1]

        if not input or input == "" then
            TBH.Msg("Usage: tbh_hotload <workshop id or url>")
            return
        end

        TBH.Server.Request(ply, input, true, "")
    end)

    concommand.Add("tbh_list", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        local count = 0
        MsgC(TBH.Colors.tag, "\n[Hotloader] server hotload registry:\n")

        for wsid, data in pairs(TBH.Server.Mounted) do
            count = count + 1
            MsgC(TBH.Colors.textdim, "  ", TBH.Colors.text, wsid, TBH.Colors.textdim,
                " - " .. (data.title or "?") .. " (" .. data.files .. " files, " ..
                tostring(data.errors) .. " errors, " .. os.date("%H:%M", data.time) .. ")\n")
        end

        if count == 0 then
            MsgC(TBH.Colors.textdim, "  nothing yet\n")
        end

        MsgC(TBH.Colors.tag, "\n")
    end)

    concommand.Add("tbh_resync", function(ply)
        if IsValid(ply) then return end -- players use the client command

        for _, p in ipairs(player.GetAll()) do
            TBH.Server.SendSyncList(p)
        end

        TBH.Msg("Re-synced every player.")
    end)

    TBH.Net:Receive("hello", function(len, ply)
        if not IsValid(ply) then return end

        TBH.Net:Start("info")
        net.WriteUInt(math.Clamp(TBH.CVarPermission:GetInt(), 0, 2), 8)
        net.WriteBool(TBH.CVarRequirements:GetBool())
        net.WriteBool(TBH.ServerCanUGC or false)
        net.WriteUInt(math.Clamp(table.Count(TBH.Server.Mounted), 0, 65535), 16)
        net.WriteString(TBH.Version)
        net.Send(ply)
    end)
end

--------------------------------------------------------------------------------
-- Client console command for hotloading (routes through the server)
--------------------------------------------------------------------------------

if CLIENT then
    concommand.Add("tbh_hotload", function(ply, cmd, args)
        local input = args and args[1]

        if not input or input == "" then
            TBH.NotifyLocally("Usage: tbh_hotload <workshop id or url>", 3)
            return
        end

        TBH.RequestHotload(input, "")
    end)
end

--------------------------------------------------------------------------------
-- Server boot banner
--------------------------------------------------------------------------------

if SERVER then
    timer.Simple(3, function()
        MsgC(TBH.Colors.tag, "\n")
        MsgC(TBH.Colors.tag, "  ============================================================\n")
        MsgC(TBH.Colors.tag, "   HOTLOADER v" .. TBH.Version .. " (SERVER)\n")
        MsgC(TBH.Colors.tag, "  ============================================================\n")

        if TBH.ServerCanUGC then
            MsgC(TBH.Colors.ok, "   gmsv_workshop module: LOADED - server-side downloads enabled\n")
        elseif game.IsDedicated() then
            MsgC(TBH.Colors.error, "   gmsv_workshop module: MISSING (dedicated server!)\n")
            MsgC(TBH.Colors.error, "   Hotloading will NOT work until you install it:\n")
            MsgC(TBH.Colors.text, "     1. Download gmsv_workshop v3.0.4+ (win64/linux64) from\n")
            MsgC(TBH.Colors.text, "        https://github.com/nooshstuff/gmsv_workshop/releases\n")
            MsgC(TBH.Colors.text, "     2. Drop it into garrysmod/lua/bin/ (create the folder)\n")
            MsgC(TBH.Colors.text, "     3. Restart the server\n")
        else
            MsgC(TBH.Colors.warn, "   gmsv_workshop module: not installed (listen server)\n")
            MsgC(TBH.Colors.text, "   Downloads will be routed through the host player instead.\n")
        end

        MsgC(TBH.Colors.text, "   Console: tbh_hotload <id or url> | tbh_loadmap | tbh_list | tbh_resync | tbh_wipe\n")
        MsgC(TBH.Colors.tag, "  ============================================================\n\n")
    end)
end
