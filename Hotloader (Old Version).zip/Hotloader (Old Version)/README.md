  HOTLOADER  v1.5.1
  Hotload ANY Steam Workshop addon into a running server. No restart.


  WORKSHOP LISTING (when you upload it)
--------------------------------------------------------------------------------
  Suggested title:  "Hotloader - Workshop Hotloader"
  or simply "Workshop Hotloader"
  (stands out, ends with Hotloader, and people searching "workshop hotloader"
  or just "hotloader" will find it)

  Icon: use workshop_icon_512.png from this zip (512x512 PNG, neon-green
  lightning bolt + HOTLOADER - matches the in-game tab icon).


WHAT IS THIS?
--------------------------------------------------------------------------------
Hotloader downloads, mounts and fully initializes Steam Workshop addons in
the MIDDLE of a live game:

  * Downloads the .gma through the server (gmsv_workshop module)
  * Mounts it with game.MountGMA
  * Runs its Lua: autorun files, scripted entities, weapons, toolgun tools,
    effects, panels, gamemode hooks - everything a fresh boot would load
  * Every connected player gets the addon synced automatically, and players
    who join later get synced when they connect
  * AUTO-HOTLOAD: subscribe to a Workshop addon in-game (Steam overlay)
    and it hotloads by itself, or tick an addon back ON in the Addons
    menu (it is already downloaded, so that one is instant).
    Both have their own checkbox in the Hotloader tab
  * MAP HOTLOADING: hotload a map addon and a LOAD MAP button appears -
    the server switches to it and every player can join (they all have
    the map mounted)
  * SOFT UNLOAD: the UNLOAD button strips an addon's hooks, timers and
    spawnmenu entries (files stay mounted - GMod cannot unmount, see
    UNLOADING below)
  * The Hotloader tab keeps track of EVERYTHING you do: every addon you
    hotload, enable or request shows up in the "YOUR ADDONS THIS SESSION"
    list the moment you click
  * SESSION SAFEGUARD: hotloads only live in memory. Restart = brand new,
    and when the last player leaves the session registry wipes itself
    (see SESSION LIFECYCLE below)

  * Addon Is Open Source
  (You can use it for whatever you want, and or contribute if you wish, No Credit Is Needed)

It is a from-scratch rewrite inspired by "Midgame Workshop Hotloader" by
Xalalau Xubilozo, rebuilt around a SERVER-DRIVEN pipeline so it works on
DEDICATED servers (the original only worked on listen servers).


REQUIREMENTS
--------------------------------------------------------------------------------
  * Garry's Mod server (x86-64 branch recommended - you said you run 64-bit)
  * DEDICATED SERVERS/LISTEN SERVERS: the gmsv_workshop module
      https://github.com/nooshstuff/gmsv_workshop
      (maintained fork with the Steamworks API updated to v1.64 - use v3.0.4
      or newer, especially on 64-bit)
  * LISTEN SERVERS / SINGLEPLAYER: nothing extra needed (the module is
    optional; without it downloads route through the host player)


INSTALLATION
--------------------------------------------------------------------------------
1. THE ADDON (one file, that's the whole thing)

   Copy hotloader.lua into:

       garrysmod/lua/autorun/hotloader.lua

   (The zip also ships a lua/autorun/ folder copy - you can extract that
   straight into your garrysmod folder instead.)

   Clients do NOT need to install anything - the server sends them the file
   automatically when they join.

2. THE gmsv_workshop MODULE (dedicated servers only)

   a) Find out which build you need - run this in your SERVER console:

      lua_run print("gmsv_workshop_" .. ((system.IsLinux() and "linux" .. (jit.arch == "x86" and "" or "64")) or (system.IsWindows() and "win" .. (jit.arch == "x86" and "32" or "64")) or "UNSUPPORTED") .. ".dll")

      On a 64-bit server this prints:
        Windows: gmsv_workshop_win64.dll
        Linux:   gmsv_workshop_linux64.dll

   b) Download that file from the maintained fork's releases:
      https://github.com/nooshstuff/gmsv_workshop/releases
      (v3.0.4 or newer: https://github.com/nooshstuff/gmsv_workshop/releases/tag/v3.0.4)

   c) Drop it into:  garrysmod/lua/bin/   (create the lua/bin folder if it
      does not exist)

   d) Restart the server. IMPORTANT for 64-bit Linux: start the server with
      srcds_run_x64, NOT srcds_run, otherwise the module will not load
      ("Couldn't load module library!").

   Hotloader auto-detects the module on boot and prints its status in the
   server console. If it is missing on a dedicated server you get a loud
   warning and hotload requests are refused with instructions.


OPTIONAL BUT RECOMMENDED: GModPatchTool (better browser)
--------------------------------------------------------------------------------
Garry's Mod ships with an ANCIENT web engine (CEF), so modern websites -
including parts of the Steam Community pages - render poorly in the built-in
browser: missing images, empty addon lists, broken layouts.

GModPatchTool by Solstice Game Studios patches GMod with a modern Chromium
engine. With it installed, the Web Browser renders Steam pages just like a
real browser. It is 100% OPTIONAL - the hotloader itself works perfectly
without it, it just makes the browser look better.

  Download: https://github.com/solsticegamestudios/GModPatchTool
  Releases: https://github.com/solsticegamestudios/GModPatchTool/releases
  (latest tested release: https://github.com/solsticegamestudios/GModPatchTool/releases/tag/20260722)

(It also fixes common GMod launch/performance issues, especially on
Linux/Proton/macOS - a nice bonus for dedicated boxes.)


QUICK START
--------------------------------------------------------------------------------
  1. Join the server, press Q. In the TOP TAB ROW (where Spawnlists,
     Weapons, NPCs, Saves, Dupes are) you now have two new tabs at the end:

       * "Hotloader" (lightning icon) - paste a Workshop URL / addon ID and
         smash the big green button. Below it: the auto-hotload checkboxes
         and the "YOUR ADDONS THIS SESSION" list - every addon you hotload,
         enable or request shows up there the instant you click, with live
         status (requested -> downloading -> mounted). Each entry is a card
         with the addon's workshop preview image, its author and UNLOAD /
         LOAD MAP buttons right on the card.
       * "Web Browser" (globe icon) - the Hotloader Browser, always ready
         in the tab. Its home page shows a couple of RANDOM featured addons
         every time you open it. Open any addon page (e.g.
         https://steamcommunity.com/sharedfiles/filedetails/?id=3787100606)
         and hit the big green button next to Subscribe.

  2. A few seconds later the addon is live on the server AND on every player.
     Weapons/entities show up in the spawnmenu tabs, tools show up in the
     tool menu (the spawnmenu refreshes itself after a hotload).

  3. Even easier: subscribe to the addon in the Steam overlay while playing
     (auto-hotloads), or tick a downloaded addon back ON in the main menu
     Addons list (hotloads instantly). Both have their own checkbox in the
     Hotloader tab.

  4. Hotloaded a MAP addon? A green LOAD MAP button appears on its session
     row (and map pages in the browser show LOAD MAP instead of HOTLOAD).
     Click it and the server switches to that map - every player can join
     because they all have the map mounted.

  5. Late joiners? They receive every hotloaded addon automatically a few
     seconds after connecting.


AUTO-HOTLOAD CHECKBOXES
--------------------------------------------------------------------------------
Both live in the Hotloader tab (and in Utilities -> Hotloader -> Settings &
Info). Each one says exactly what it does when you hover over it:

  [x] Auto-Hotload on Subscribe   (convar: tbh_autosubscribe)
      When ON: subscribing to a NEW Workshop addon while in-game (Steam
      overlay) automatically requests a hotload. The addon downloads first,
      then the request fires. Server permission still applies.

  [x] Enable Addons                (convar: tbh_enableaddons)
      When ON: ticking an addon back ON in the main menu "Addons" list
      automatically hotloads it. The addon is already downloaded on your
      PC, so this is nearly instant - it just mounts it and syncs it to
      everyone. Server permission still applies.

The server always re-checks permissions, cooldown and queue - the
checkboxes only decide whether YOUR client sends the request.


MAP HOTLOADING ("LOAD MAP") - AND THE LOADING SCREEN
--------------------------------------------------------------------------------
Hotload any addon that contains .bsp files (map packs, single maps):

  * In the BROWSER: map addon pages automatically show a LOAD MAP button
    instead of HOTLOAD (it reads the page's Map tag). Clicking it hotloads
    the addon AND switches the server to the map (if the addon contains
    exactly one map; map packs with several maps tell you to pick one).
  * In the HOTLOADER TAB: a green LOAD MAP button appears on the addon's
    row (right-click menu lists every map if it contains several).
  * The server announces the change and switches the level 5 seconds later.

  *** WAIT FOR THE MAP - DO NOT DISCONNECT! ***

  After the level change you may sit on "Establishing connection to
  server" / "Sending client info" for a while. THAT IS NORMAL: your game
  is DOWNLOADING the map from the server (players who subscribed/hotloaded
  the addon already have it and load instantly). Big maps are hundreds of
  megabytes - on a slow connection that can take several minutes. Just
  wait, the loading screen finishes on its own. A 10-second on-screen hint
  reminds everyone of this when the map change is announced.

  Console: tbh_loadmap <mapname>   (same permission as hotloading)


UNLOADING - THE HONEST ANSWER
--------------------------------------------------------------------------------
You heard right: FULLY unloading a hotloaded addon is impossible in pure
Lua. GMod has NO unmount API - game.MountGMA has no inverse, and Facepunch's
own request for one (garrysmod-requests #275) has been open since 2014.
Mounted files stay mounted until the game restarts. Even a Rust/C++ binary
calling IFileSystem::RemoveSearchPath could only remove the search path -
models/materials already loaded into the engine stay cached. (No module is
shipped for this: an untested binary module on a live server is a bad idea,
and it can't be compiled/tested for your platform here.)

What IS possible - and what Hotloader does with SOFT UNLOAD (the UNLOAD
button on each addon row, right-click -> Unload, or tbh_unload <id> [1]):

  REMOVED:
    * every hook the addon registered
    * every timer the addon created
    * its spawnmenu entries (entities/weapons vanish from the Q menu)
    * optionally (pass 1 / the second button): every entity the addon's
      classes spawned + strips held weapons of its classes
    * runs on the server AND broadcasts so every client unloads too

  KEPT (cannot be removed without a restart):
    * the mounted files themselves (models, materials, sounds - harmless,
      just disk/memory usage)
    * the class tables inside weapons/scripted_ents (GMod's lists have no
      unregister API - they're hidden from the menus instead)

So after a soft unload the addon is behaviorally gone: no hooks, no timers,
nothing in the menus, no entities. A map change + re-hotload is the clean
"reload" if something misbehaves.


SESSION LIFECYCLE (the safeguard)
--------------------------------------------------------------------------------
Hotloaded addons ONLY live in memory - nothing is ever written to disk by
Hotloader. That means:

  * Server restart = completely brand new. Nothing hotloaded "exists"
    anymore until you hotload it again. The session list follows: it wipes
    itself every time you spawn into a fresh map/server, so you never see
    addons from a previous session (no full game restart needed).
  * When the LAST player leaves (host included), the server automatically
    wipes the entire hotload session registry (mounted list, queue,
    cooldowns, everything), so the next session on a long-running server
    starts 100% clean. Toggle with tbh_cleanup_on_empty (default 1).
  * Want to reset mid-session? Admins can run tbh_wipe in the console -
    every hotloaded addon is forgotten instantly.
  * LIMITATION: if you disconnect and reconnect to the same server, the
    addons come straight back - the server still has them mounted for
    its current session and re-syncs them to you, and your client cannot
    unmount files. Fully clearing = leave + restart your game.
  * Note: Steam keeps its own download cache (garrysmod/cache) - that is
    Steam's business, managed by Steam, and is what makes re-hotloading
    the same addon instant. It never mounts anything by itself.


CONSOLE COMMANDS
--------------------------------------------------------------------------------
  tbh_hotload <id or url>   Request a hotload (permission checked server-side)
  tbh_loadmap <mapname>     Switch the level to a hotloaded map (admin)
  tbh_unload <id> [1]       Soft-unload an addon (1 = also remove entities)
  tbh_wipe                  (admin) forget every hotloaded addon instantly
  tbh_browser [url]         Open the embedded web browser in a window
  tbh_menu                  Open the hotloader panel in a standalone window
  tbh_list                  List everything hotloaded this session
  tbh_resync                Re-download all hotloaded addons (client) or
                            re-sync every player (server console)
  tbh_give_hints            Show the welcome hints again
  tbh_syncstatus            (server console) show which players failed to sync


CONSOLE VARIABLES (server)
--------------------------------------------------------------------------------
  tbh_permission        1   Who may hotload: 0 everyone, 1 admins, 2 superadmins
  tbh_requirements      1   Also hotload an addon's Required Items automatically
  tbh_max_files     20000   Max files per addon
  tbh_timeout         180   Download watchdog in seconds
  tbh_cooldown         10   Per-player request cooldown in seconds
  tbh_max_queue         10   Max queued hotloads at once
  tbh_latesync          1   Sync addons to players who join later
  tbh_announce          1   Chat announcements when addons get hotloaded
  tbh_cleanup_on_empty  1   Wipe the session registry when the last player
                            leaves (restart-clean guarantee)

CONSOLE VARIABLES (client)
--------------------------------------------------------------------------------
  tbh_autosubscribe  1   Auto-hotload when you subscribe to a NEW Workshop
                        addon in-game (Steam overlay)
  tbh_enableaddons   1   Auto-hotload when you tick a downloaded addon back
                        ON in the Addons menu (instant - already downloaded)
  tbh_hints          1   Welcome hints
  tbh_logs           0   Verbose hotload logs in the console

PERMISSIONS
--------------------------------------------------------------------------------
Default is ADMINS ONLY (tbh_permission 1) because hotloading runs addon Lua on
your server. The listen-server host is always allowed regardless of setting.
Change it with:  tbh_permission 0   (everyone) or  tbh_permission 2
(superadmins only). Server console is always allowed.


HOW IT WORKS (the short version)
--------------------------------------------------------------------------------
  Request  -> permission check + cooldown + queue (one download at a time)
          -> requirement scrape (steamcommunity.com "Required Items")
          -> steamworks.DownloadUGC on the SERVER (gmsv_workshop module)
          -> game.MountGMA
          -> "Bundle" initialization on the server realm:
             autorun, entities, weapons, stools, lifecycle hooks...
          -> broadcast "mount" to every player
          -> each client downloads + mounts + initializes client-side Lua
          -> clients report results back, server logs sync failures
          -> late joiners get the full list on connect (tbh_latesync)

  Listen servers WITHOUT the module instead ask the host player's client to
  download, then stream the mounted file list back to the server in 60KB
  chunks, initialize the server side, and broadcast to everyone else.

  Hotloaded addons run inside a sandboxed environment: their hooks, timers,
  includes and requires are tracked per-bundle, they see the "fresh boot"
  world state during initialization (no players/entities), and their custom
  ammo types are emulated at runtime (the ammo API is detoured).


TROUBLESHOOTING
--------------------------------------------------------------------------------
  "gmsv_workshop module: MISSING" on boot (dedicated)
      Install the module - see INSTALLATION step 2 (the nooshstuff fork,
      v3.0.4+). Make sure you got the win64/linux64 build and you launch
      with srcds_run_x64 on Linux.

  "Couldn't load module library!"
      Your server is on the x86-64 branch but running in 32-bit. Start with
      srcds_run_x64 instead of srcds_run. (Or the server needs an update,
      or the module build is older than the server's Steamworks - grab the
      newest release from the nooshstuff fork.)

  Download fails / times out
      The addon is hidden, removed, or Steam is unreachable from the server.
      Wait a minute and retry (failed ids get a 60s cooldown server-side).

  "addon has N files (limit: ...)"
      Raise tbh_max_files.

  The addon loads but has Lua errors
      Check the console - bundle errors are printed with the addon name.
      Some very old/broken addons simply cannot be hotloaded. Hooks, weapons
      and entities from other bundles keep working.

  Tools do not appear in the tool menu
      The spawnmenu refreshes ~1s after a hotload. If a tool is still missing
      from the list you can force it with:  gmod_tool <toolname>

  Players see error models / missing textures
      They have not finished syncing yet. They can run tbh_resync, or just
      reconnect. Big addons take a while to download on the client.

  Stuck on "Establishing connection to server" after a map change
      NORMAL - your game is downloading the map from the server. Big maps
      take minutes on slow connections. DO NOT DISCONNECT, just wait (see
      MAP HOTLOADING above).

  The browser shows a blank page
      The server or client cannot reach the website, or the site blocks
      embedded browsers. The Workshop itself always works. You can also use
      the HOTLOAD button in the browser toolbar - it parses the URL in the
      address bar and does not need the page at all.

  The browser renders Steam pages badly (missing images, empty lists)
      That is GMod's ancient built-in web engine, not the hotloader.
      Install GModPatchTool (OPTIONAL - see the section above) to give GMod
      a modern web engine; the browser looks way better with it.

  I subscribed to an addon but nothing happened
      Auto-subscribe requests still go through the server's permission check
      - non-admins are denied by default (tbh_permission 1). Make sure you are
      allowed to hotload, and check the right checkbox is on ("Auto-Hotload
      on Subscribe" for new subscriptions, "Enable Addons" for re-enabling
      downloaded ones). Also note the request fires once the addon finishes
      downloading, a few seconds after you hit Subscribe.

  I enabled an addon in the Addons menu but nothing happened
      Same as above, but the "Enable Addons" checkbox governs this path - it
      fires nearly instantly because the addon is already downloaded.

  LOAD MAP says the map doesn't exist
      Hotload the map addon FIRST (the server needs the .bsp mounted), then
      hit LOAD MAP. The button only appears for addons containing maps. If
      you used the browser's LOAD MAP button on a map pack with several
      maps, pick the map from its row's right-click menu instead.

  The Hotloader / Web Browser tabs don't show in the spawnmenu
      They sit at the END of the top tab row (after Saves/Dupes). If you
      still don't see them, run spawnmenu_reload in the console. On
      non-sandbox-derived gamemodes the spawnmenu may look different.

  Can I fully unload an addon?
      No - and nobody else can in pure Lua either. See UNLOADING above for
      the honest explanation. Soft unload (hooks/timers/menus/entities)
      works fine.

  Do hotloads persist after a restart?
      No, and that's by design. Everything lives in memory; a restart is
      always brand new, and the session registry even wipes itself when
      the last player leaves (tbh_cleanup_on_empty).

  I disconnected and reconnected and the addon is still there
      That is a LIMITATION, not a bug - and it needs a restart to fully
      clear. Two things are at play:
        * The SERVER keeps every hotloaded addon mounted and running for
          as long as it has players (that is the point - other players
          are using them). When you reconnect, the server re-syncs them
          to you, so they show up in your list again.
        * Your game client cannot unmount files, so anything it mounted
          stays mounted until you restart Garry's Mod completely.
      To fully clear everything: leave the server (if you were the last
      player the server wipes its session), then restart your game. A
      fresh session always starts 100% clean.


CREDITS & LICENSE
--------------------------------------------------------------------------------
  * Architecture inspired by "Midgame Workshop Hotloader" by Xalalau Xubilozo
    (https://steamcommunity.com/sharedfiles/filedetails/?id=2885846408).
    The sandboxed-bundle approach and runtime ammo emulation are based on
    ideas from that addon, rewritten from scratch for a server-driven
    pipeline. It does NOT contact the original author's error-reporting
    service - Hotloader reports nowhere, everything stays local.
  * gmsv_workshop module - original by WilliamVenner
    (https://github.com/WilliamVenner/gmsv_workshop); use the maintained
    fork by nooshstuff with the Steamworks API updated to v1.64:
    https://github.com/nooshstuff/gmsv_workshop (v3.0.4+). REQUIRED on
    dedicated servers, download it separately.
  * GModPatchTool by Solstice Game Studios
    (https://github.com/solsticegamestudios/GModPatchTool) - OPTIONAL, gives
    GMod a modern web engine so the built-in browser renders pages properly.
  * Use it, mod it, ship it. No warranty. Hotloading runs third-party Lua on
    your server - keep permissions at admins-only on public servers.


    (This Description was written by Z.AI And yes i did write this part)
